"""Shell commands an AI must never run, even inside the sandbox container (destructive, escaping, backdoors). Shared by the bot (friendly refusal) and the server (enforcement)."""
from __future__ import annotations

import re

_DANGER = (
    r"\brm\s+(?:-[a-zA-Z]*\s+)*(?:-[a-zA-Z]*[rRf][a-zA-Z]*\s+)+(?:--no-preserve-root\s+)?(?:/|/\*|~|~/\*?|\$HOME|\.\.?/?|\*)(?:\s|$)",
    r":\s*\(\s*\)\s*\{", r"\bmkfs(?:\.\w+)?\b", r"\bdd\s+[^|;]*\bof=/dev/", r">\s*/dev/(?:sd|nvme|vd|hd)", r"\bchmod\s+-R\s+[0-7]{3,4}\s+/(?:\s|$)", r"\bchown\s+-R\s+\S+\s+/(?:\s|$)",
    r"\b(?:shutdown|reboot|halt|poweroff|init\s+0)\b", r"\bkill\s+-9\s+-1\b", r"\bkillall5?\b", r"\b(?:sudo|su)\b", r"\bdocker\b|\bpodman\b|\bmount\b|\bumount\b|\bchroot\b|\bnsenter\b",
    r"\b(?:curl|wget)\b[^\n|;]*\|\s*(?:sudo\s+)?(?:ba|z|da)?sh\b", r"/dev/(?:tcp|udp)/", r"\b(?:nc|ncat|socat)\b[^\n]*\s-(?:e|c)\b", r"/proc/(?:\d+|self)/environ",
    r"\bssh(?:-keygen)?\b|\bscp\b", r"\bcrontab\b|\bsystemctl\b|\bservice\s+\w+\s+(?:start|stop)", r"\biptables\b|\bnft\b|\bip\s+(?:route|link)\b",
)
DANGER_RE = re.compile("|".join(_DANGER), re.I)


def dangerous_command(cmd: str) -> str | None:
    """A reason when a shell command written by the AI is destructive / escapes the sandbox / opens a backdoor; None when it is an ordinary command."""
    m = DANGER_RE.search(cmd or "")
    return m.group(0).strip()[:40] if m else None
