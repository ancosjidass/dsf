"""Two-player rock-paper-scissors with secret inline-button choices.

    .rps            open a duel in this chat (PV: the other person is the opponent; group: the first
                    person who presses a button joins; Reply to someone = challenge exactly that person)
    .rps 5          best of 5 (odd, 1..9; default 3)
    .rps rock       old solo game against the bot (unchanged)

The match message is posted by the Assistant Bot (BOT_TOKEN), so the buttons work for everybody.
It is sent through *inline mode* (works in PVs and in groups the bot is not a member of) - enable it once in
@BotFather: /setinline -> your bot. Without inline mode the bot posts the message itself (needs membership).
Choices are secret (only shown to the person who pressed). Stats go to the OWNER's own database.
"""
from __future__ import annotations

import logging
import os
import re
import secrets
import time
from dataclasses import dataclass, field
from typing import Any

from telethon import Button, events

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."

CHOICES = {"r": "🪨 سنگ", "p": "📄 کاغذ", "s": "✂️ قیچی"}
BEATS = {("r", "s"), ("p", "r"), ("s", "p")}
GAME_TTL = 3600


def round_winner(a: str, b: str) -> int:
    """0 = draw, 1 = first player wins, 2 = second player wins."""
    if a == b:
        return 0
    return 1 if (a, b) in BEATS else 2


@dataclass
class Duel:
    token: str
    owner_uid: int
    owner_name: str
    chat_id: int
    best_of: int = 3
    opp_uid: int | None = None
    opp_name: str = ""
    fixed_opp: bool = False
    picks: dict[int, str] = field(default_factory=dict)
    score: dict[int, int] = field(default_factory=dict)
    round_no: int = 1
    log_lines: list[str] = field(default_factory=list)
    created: float = field(default_factory=time.time)
    finished: bool = False

    @property
    def need(self) -> int:
        return self.best_of // 2 + 1

    def header(self) -> str:
        opp = self.opp_name or "❓ (منتظر حریف)"
        o, p = self.score.get(self.owner_uid, 0), self.score.get(self.opp_uid or -1, 0)
        return f"✂️ <b>سنگ‌کاغذ‌قیچی</b> — بهترین از {self.best_of}\n👤 {self.owner_name}  <b>{o}</b> : <b>{p}</b>  {opp}"

    def body(self) -> str:
        text = self.header()
        if self.log_lines:
            text += "\n\n" + "\n".join(self.log_lines[-5:])
        if not self.finished:
            waiting = [n for uid, n in ((self.owner_uid, self.owner_name), (self.opp_uid, self.opp_name)) if uid and uid not in self.picks]
            text += f"\n\n🎯 دور {self.round_no} — انتخاب کنید (مخفی می‌مونه)"
            if self.picks:
                text += "\n⏳ منتظر: " + (waiting[0] if waiting else "حریف")
        return text


GAMES: dict[str, Duel] = {}
_bot: Any = None
_fleet: Any = None


def _gc() -> None:
    now = time.time()
    for k in [k for k, g in GAMES.items() if now - g.created > GAME_TTL]:
        GAMES.pop(k, None)


def new_duel(owner_uid: int, owner_name: str, best_of: int = 3, chat_id: int = 0) -> Duel:
    """Create + register a duel (used by .rps, the inline menu and `@bot rps`)."""
    _gc()
    game = Duel(secrets.token_urlsafe(6), int(owner_uid), owner_name, int(chat_id), best_of)
    GAMES[game.token] = game
    return game


def _buttons(token: str, finished: bool = False):
    if finished:
        return None
    return [[Button.inline(label, f"rps:{token}:{key}".encode()) for key, label in CHOICES.items()],
            [Button.inline("🚪 انصراف (فقط صاحب بازی)", f"rps:{token}:x".encode())]]


def _display(entity) -> str:
    n = " ".join(x for x in (getattr(entity, "first_name", None), getattr(entity, "last_name", None)) if x)
    return n or getattr(entity, "title", None) or getattr(entity, "username", None) or "؟"


async def _record(game: Duel, owner_won: bool | None) -> None:
    """Update duel statistics inside the OWNER's own database."""
    rt = _fleet.runtime_for_user(game.owner_uid) if _fleet is not None else None
    if rt is None:
        return
    stats = await rt.db.get_kv("rps:duel", {"wins": 0, "losses": 0, "draws": 0}) or {}
    key = "draws" if owner_won is None else "wins" if owner_won else "losses"
    stats[key] = int(stats.get(key, 0)) + 1
    await rt.db.set_kv("rps:duel", stats)


def setup(client, db):
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}rps(?:\s+(\d))?$"))
    async def rps_duel(event):
        if _bot is None:
            return await event.reply("❌ برای بازی دو نفره Assistant Bot لازمه (BOT_TOKEN در .env).")
        _gc()
        best_of = int(event.pattern_match.group(1) or 3)
        if best_of % 2 == 0 or not 1 <= best_of <= 9:
            return await event.reply("❌ تعداد دست‌ها باید فرد و بین ۱ تا ۹ باشه (مثلاً `.rps 5`).")
        me = await client.get_me()
        game = Duel(secrets.token_urlsafe(6), int(me.id), _display(me), int(event.chat_id), best_of)
        opponent = None
        if event.is_reply:
            m = await event.get_reply_message()
            opponent = await m.get_sender() if m else None
        elif event.is_private:
            opponent = await event.get_chat()
        if opponent is not None and getattr(opponent, "id", None) and int(opponent.id) != game.owner_uid and not getattr(opponent, "bot", False):
            game.opp_uid, game.opp_name, game.fixed_opp = int(opponent.id), _display(opponent), True
        GAMES[game.token] = game
        reply_to = event.reply_to_msg_id
        try:
            username = (await _bot.get_me()).username
            results = await client.inline_query(username, f"rps {game.token}")
            if not results:
                raise RuntimeError("no inline results")
            await results[0].click(event.chat_id, reply_to=reply_to)
        except Exception as exc:  # noqa: BLE001  - inline mode off: let the bot post it directly
            log.info("rps inline failed (%s: %s); falling back to bot.send_message", exc.__class__.__name__, exc)
            try:
                await _bot.send_message(event.chat_id, game.body(), parse_mode="html", buttons=_buttons(game.token))
            except Exception as exc2:  # noqa: BLE001
                GAMES.pop(game.token, None)
                return await event.reply(
                    "❌ Assistant Bot نتونست بازی رو بفرسته.\n"
                    "• در @BotFather دستور /setinline بزن و برای بات Inline رو روشن کن، یا\n"
                    f"• بات رو عضو این گروه کن.\n({exc2.__class__.__name__})")
        try:
            await event.delete()
        except Exception:  # noqa: BLE001
            pass


def attach(bot, fleet) -> None:
    """Called once from ui.attach(): inline + callback handlers live on the shared Assistant Bot."""
    global _bot, _fleet
    _bot, _fleet = bot, fleet

    @bot.on(events.InlineQuery(pattern=r"^rps\s+(\S+)$"))
    async def on_inline(event):
        game = GAMES.get(event.pattern_match.group(1))
        if game is None or event.sender_id != game.owner_uid:
            return await event.answer([], cache_time=0, switch_pm=None)
        await event.answer([event.builder.article(
            "✂️ سنگ‌کاغذ‌قیچی", text=game.body(), parse_mode="html", buttons=_buttons(game.token), description="شروع بازی دو نفره")],
            cache_time=0)

    @bot.on(events.CallbackQuery(pattern=rb"rps:.*"))
    async def on_click(event):
        try:
            _, token, key = event.data.decode().split(":", 2)
        except ValueError:
            return await event.answer("دکمهٔ نامعتبر", alert=True)
        game = GAMES.get(token)
        if game is None or game.finished:
            return await event.answer("این بازی تموم شده یا منقضی شده.", alert=True)
        uid = int(event.sender_id)
        if key == "x":
            if uid != game.owner_uid:
                return await event.answer("فقط صاحب بازی می‌تونه لغو کنه.", alert=True)
            game.finished = True
            game.log_lines.append("🚪 بازی لغو شد.")
            await event.edit(game.body(), parse_mode="html", buttons=None)
            GAMES.pop(token, None)
            return
        if key not in CHOICES:
            return await event.answer("انتخاب نامعتبر", alert=True)
        if uid != game.owner_uid:
            if game.opp_uid is None:
                sender = await event.get_sender()
                game.opp_uid, game.opp_name = uid, _display(sender)
            elif uid != game.opp_uid:
                return await event.answer("این بازی دو نفره‌ست و حریفش مشخصه. ✋", alert=True)
        if uid in game.picks:
            return await event.answer(f"قبلاً انتخاب کردی: {CHOICES[game.picks[uid]]}", alert=True)
        game.picks[uid] = key
        await event.answer(f"انتخابت: {CHOICES[key]} ✅")
        if game.opp_uid is None or len(game.picks) < 2:
            return await event.edit(game.body(), parse_mode="html", buttons=_buttons(token))
        a, b = game.picks[game.owner_uid], game.picks[game.opp_uid]
        w = round_winner(a, b)
        who = "🤝 مساوی" if w == 0 else f"🏅 {game.owner_name if w == 1 else game.opp_name}"
        game.log_lines.append(f"دور {game.round_no}: {CHOICES[a]}  vs  {CHOICES[b]} → {who}")
        if w:
            win_uid = game.owner_uid if w == 1 else game.opp_uid
            game.score[win_uid] = game.score.get(win_uid, 0) + 1
        game.picks.clear()
        game.round_no += 1
        o, p = game.score.get(game.owner_uid, 0), game.score.get(game.opp_uid, 0)
        if o >= game.need or p >= game.need:
            game.finished = True
            champion = game.owner_name if o > p else game.opp_name
            game.log_lines.append(f"\n🏆 <b>برنده: {champion}</b>")
            await _record(game, o > p)
            GAMES.pop(token, None)
        elif game.round_no > game.best_of * 3:  # endless draws
            game.finished = True
            game.log_lines.append("\n🤝 بازی مساوی تموم شد.")
            await _record(game, None)
            GAMES.pop(token, None)
        await event.edit(game.body(), parse_mode="html", buttons=_buttons(token, game.finished))
