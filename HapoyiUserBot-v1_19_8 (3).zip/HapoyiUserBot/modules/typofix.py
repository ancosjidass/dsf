"""Command typo fixer (1.19.6): you write `.mutee @x` -> «❓ منظورت `.mute @x` بود؟  `.y` = اجرا».

    .y        runs the suggested command (valid for 90 seconds, in the same chat)
    .typo on|off|status        (default ON; only an ASCII word of 3+ letters that is no command / alias / macro / snippet and is very close to one)
"""
from __future__ import annotations

import difflib
import logging
import os
import re
import time

from telethon import events

from core.runcmd import run_as_me
from services import knowledge as K

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
TTL = 90.0
WORD_RE = re.compile(rf"^{P}([A-Za-z][A-Za-z0-9_]{{2,19}})(?=\s|$)")


def pattern_words(pattern: str) -> set[str]:
    """The command words a handler pattern can start with: `^\\.(?:banned(?:\\s+users)?|ban\\s+users|banlist)` -> banned, ban, banlist, users ..."""
    head = pattern[:80].lstrip("^")
    head = re.sub(r"^\(\?s\)|^\(\?[a-z]+\)", "", head).lstrip("^")
    head = re.sub(r"^\\?\.|^\{?P?\}?", "", head, count=1)
    return {w.lower() for w in re.findall(r"[A-Za-z]{3,}", head)}


def suggest(word: str, known: set[str]) -> str | None:
    """The command `word` was most likely meant to be, or None when it is a command / not close enough to one."""
    w = word.lower()
    if w in known:
        return None
    best = difflib.get_close_matches(w, sorted(known), n=1, cutoff=0.78)
    if not best:
        return None
    b = best[0]
    if abs(len(b) - len(w)) > 2 or b[0] != w[0] and sorted(b) != sorted(w):
        return None
    return b


def setup(client, db):
    pending: dict[int, tuple[float, str, int | None]] = {}
    cache = {"words": None, "n": 0}

    def known_words() -> set[str]:
        try:
            handlers = list(client.list_event_handlers())
        except Exception:  # noqa: BLE001
            handlers = []
        if cache["words"] is None or cache["n"] != len(handlers):
            words = set(K.known_commands())
            for _cb, builder in handlers:
                pat = getattr(getattr(builder, "pattern", None), "__self__", None)
                if pat is not None and getattr(pat, "pattern", ""):
                    words |= pattern_words(pat.pattern)
            cache["words"], cache["n"] = words, len(handlers)
        return cache["words"]

    async def user_words() -> set[str]:
        out: set[str] = set()
        for sql in ("SELECT word AS w FROM user_aliases", "SELECT name AS w FROM macros", "SELECT name AS w FROM plus_snippets"):
            try:
                out |= {str(r["w"]).lower() for r in await db.fetchall(sql)}
            except Exception:  # noqa: BLE001
                pass
        return out

    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}[A-Za-z]"))
    async def watcher(event):
        m = WORD_RE.match(event.raw_text or "")
        if not m or await db.get_kv("typo:off"):
            return
        word = m.group(1)
        if word.lower() in await user_words():
            return
        fixed = suggest(word, known_words())
        if fixed is None:
            return
        corrected = PREFIX + fixed + (event.raw_text or "")[m.end():]
        pending[event.chat_id] = (time.time(), corrected, event.reply_to_msg_id)
        await event.reply(f"❓ منظورت `{corrected[:200]}` بود؟\n`{PREFIX}y` = اجرا")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}y$"))
    async def yes(event):
        item = pending.pop(event.chat_id, None)
        if item is None or time.time() - item[0] > TTL:
            return await event.edit("❓ چیزی برای اجرا نیست.")
        _ts, text, reply_to = item
        replied = None
        if reply_to:
            try:
                replied = await client.get_messages(event.chat_id, ids=reply_to)
            except Exception:  # noqa: BLE001
                replied = None
        try:
            await event.delete()
        except Exception:  # noqa: BLE001
            pass
        await run_as_me(client, event.chat_id, text, reply_to=reply_to, replied=replied)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}typo(?:\s+(on|off|status))?$"))
    async def typo(event):
        word = event.pattern_match.group(1) or "status"
        if word == "on":
            await db.set_kv("typo:off", 0)
        elif word == "off":
            await db.set_kv("typo:off", 1)
        await event.edit(f"✍️ اصلاح غلط تایپی دستور: {'خاموش' if await db.get_kv('typo:off') else 'روشن'}")
