"""Your account as a group-management bot (1.18.0).

    .gbot on|off|status       in a group where YOU are admin: the group's admins (and the people you delegated) can control the group by writing
                              a command word - your account does the work, exactly as if you had typed the self's command:
        سکوت [10m] | بن | کیک | اخطار | رفع سکوت | رفع بن | حذف | پاکسازی 20 | پین | آنپین | قفل [media] | بازکردن | آهسته 30s | ارتقا | عزل | لیست بن | لیست سکوت | ادمین‌ها
        (Reply on the person's message, or add @username / id.  English words, `/ban`, `!ban`, `.ban` work too.)
        An admin can only do what HIS OWN admin rights allow (Ban Users, Delete Messages, Pin ...); nobody can act on an admin (only the group creator can).
        Level `god` (1.19.6): the delegate's command is run EXACTLY like you typing it by hand - admins included, no rule of the bot in the way; the only judge is
        Telegram itself, i.e. what YOUR account may do (it can never touch you / your own account, nor the owner when you are not the owner, nor an admin you may not edit).
    .delegate [@user|id]      (Reply) posts a panel with BUTTONS (only you can press): give that person control of the chat WITHOUT making him an admin
                              [✅ کنترل گروه] (everything except promote/demote)  [⭐ کنترل کامل]  [⚡ خدا] (like `full`, and also on admins)  [🚫 گرفتن دسترسی]
    .gbot grant|revoke [mod|full|god] [@user|id]    the same without the panel        .gbot who   the delegates of this chat

Only the chat where you switched it on is affected; nothing here touches your own messages. Commands run through the real handlers of the self
(so every rule of `.mute` `.ban` `.lock` ... applies) and your command message is removed a moment later.
"""
from __future__ import annotations

import asyncio
import html
import logging
import os
import re
import secrets
import time
from collections import defaultdict, deque
from datetime import datetime, timezone
from typing import Any

from telethon import Button, events

from core.identity import my_id
from core.permissions import clean_target, require_group_right, resolve_target
from utils.activity import display_name

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
TABLES = (
    "CREATE TABLE IF NOT EXISTS gb_chats (chat_id INTEGER PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 1)",
    "CREATE TABLE IF NOT EXISTS gb_delegates (chat_id INTEGER NOT NULL, user_id INTEGER NOT NULL, level TEXT NOT NULL DEFAULT 'mod', name TEXT, "
    "created_at TEXT NOT NULL, PRIMARY KEY (chat_id, user_id))",
)

# command of the self -> Telegram admin right the requester must have himself (None = any admin / delegate)
RIGHT: dict[str, str | None] = {
    "ban": "ban_users", "unban": "ban_users", "kick": "ban_users", "mute": "ban_users", "unmute": "ban_users", "warn": "ban_users",
    "unwarn": "ban_users", "warnings": "ban_users", "banned": "ban_users", "muted": "ban_users", "lock": "ban_users", "unlock": "ban_users",
    "del": "delete_messages", "delall": "delete_messages", "purge": "delete_messages",
    "pin": "pin_messages", "unpin": "pin_messages",
    "slowmode": "change_info",
    "promote": "add_admins", "demote": "add_admins",
    "admins": None,
    "poll": None, "sched": None, "modai": "delete_messages",
    # 1.19.5: the rest of the group features - «ربات ...» / `.gai` reach exactly what `.gai do` reaches (never `gbot`: only the owner decides who controls the group)
    "delmes": "delete_messages", "captcha": "ban_users", "linkguard": "delete_messages", "filter": "delete_messages", "flood": "delete_messages",
    "welcome": "change_info", "autoban": "ban_users", "whitelist": "ban_users", "blacklist": "ban_users", "autodelete": "delete_messages",
    "activity": None, "tag": None,
}
NEEDS_PIN_RIGHT = frozenset({"poll", "sched"})
ADMIN_ONLY_FULL = frozenset({"promote", "demote", "modai"})             # a delegate needs level `full` for these
NEEDS_PERSON = frozenset({"ban", "unban", "kick", "mute", "unmute", "warn", "unwarn", "warnings", "promote", "demote", "delall"})
NEEDS_REPLY = frozenset({"del", "pin"})
ALIASES: dict[str, str] = {
    "سکوت": "mute", "میوت": "mute", "mute": "mute",
    "رفع سکوت": "unmute", "رفع میوت": "unmute", "آنمیوت": "unmute", "انمیوت": "unmute", "unmute": "unmute",
    "بن": "ban", "ban": "ban", "رفع بن": "unban", "آنبن": "unban", "انبن": "unban", "unban": "unban",
    "کیک": "kick", "اخراج": "kick", "kick": "kick",
    "اخطار": "warn", "warn": "warn", "حذف اخطار": "unwarn", "رفع اخطار": "unwarn", "unwarn": "unwarn", "اخطارها": "warnings", "warnings": "warnings",
    "حذف": "del", "پاک": "del", "del": "del", "حذف همه": "delall", "delall": "delall",
    "پاکسازی": "purge", "purge": "purge",
    "پین": "pin", "سنجاق": "pin", "pin": "pin", "آنپین": "unpin", "انپین": "unpin", "unpin": "unpin",
    "قفل": "lock", "lock": "lock", "بازکردن": "unlock", "باز کردن": "unlock", "unlock": "unlock",
    "آهسته": "slowmode", "slowmode": "slowmode",
    "ارتقا": "promote", "ادمین کن": "promote", "promote": "promote", "عزل": "demote", "demote": "demote",
    "لیست بن": "banned", "banned": "banned", "لیست سکوت": "muted", "muted": "muted",
    "ادمین‌ها": "admins", "ادمین ها": "admins", "ادمینها": "admins", "admins": "admins",
}
HELP = ("🛠 دستورها (روی پیام فرد Reply کن، یا @username/ID بده):\n"
        "سکوت [10m] • رفع سکوت • بن • رفع بن • کیک • اخطار • حذف اخطار • حذف (Reply) • پاکسازی 20 • پین • آنپین • "
        "قفل [media] • بازکردن • آهسته 30s • لیست بن • لیست سکوت • ارتقا • عزل")
MAX_ARGS = 200
_ZW = re.compile("[‌​‎‏]")
_PANELS: dict[str, dict] = {}   # token -> {ctrl, chat, uid, name, born}   (delegation panels; the Assistant Bot is shared by every account)
_bot: Any = None


def norm(text: str) -> str:
    return _ZW.sub("", (text or "")).replace("ي", "ی").replace("ك", "ک").strip()


def parse_command(text: str) -> tuple[str, str] | None:
    """'سکوت 10m' -> ('mute','10m') ; '/ban' -> ('ban',''); 'سلام' -> None. Only the first line; never an @bot command (`/ban@SomeBot`)."""
    line = norm((text or "").split("\n", 1)[0])
    if not line or len(line) > MAX_ARGS + 30:
        return None
    parts = line.split()
    if parts[0][0] in "/!.#" and len(parts[0]) > 1:
        parts[0] = parts[0][1:]
    if "@" in parts[0]:
        return None
    for n in (3, 2, 1):
        if len(parts) >= n:
            cmd = ALIASES.get(" ".join(parts[:n]).lower())
            if cmd:
                return cmd, " ".join(parts[n:])[:MAX_ARGS]
    return None


def allowed(cmd: str, *, is_admin: bool, rights: set[str], is_creator: bool, level: str | None) -> bool:
    """May this requester run `cmd`? Admin = by his own rights. Delegate = level mod (all but promote/demote) | full | god (full + acts on admins too)."""
    need = RIGHT.get(cmd, "?")
    if need == "?":
        return False
    if level == "god":      # 1.19.6: every group command, whatever the requester is in Telegram; Telegram judges the real call
        return True
    if is_creator:
        return True
    if is_admin:
        return need is None or need in rights
    if level:
        return cmd not in ADMIN_ONLY_FULL or level in {"full", "god"}
    return False


class _Origin:
    """What `.do`'s event builder needs from the 'original message': chat + MY account as sender (the command message is mine)."""

    def __init__(self, client, chat_id: int):
        self.client, self.chat_id = client, chat_id

    async def get_chat(self):
        return await self.client.get_entity(self.chat_id)

    async def get_input_chat(self):
        return await self.client.get_input_entity(self.chat_id)

    async def get_sender(self):
        return await self.client.get_me()

    async def get_input_sender(self):
        return await self.client.get_input_entity("me")


class Controller:
    def __init__(self, client, db):
        self.client, self.db = client, db
        self.ready = False
        self.me = 0
        self.perm_cache: dict[tuple[int, int], tuple[float, Any]] = {}
        self.recent: dict[int, deque] = defaultdict(lambda: deque(maxlen=40))
        self.last_by_user: dict[tuple[int, int], float] = {}
        self.tasks: set[asyncio.Task] = set()

    async def ensure(self) -> None:
        if not self.ready:
            self.ready = True
            for stmt in TABLES:
                await self.db.execute(stmt)
            self.me = await my_id(self.client)

    async def enabled(self, chat_id: int) -> bool:
        row = await self.db.fetchone("SELECT enabled FROM gb_chats WHERE chat_id=?", (chat_id,))
        return bool(row and row["enabled"])

    async def delegate(self, chat_id: int, uid: int) -> str | None:
        row = await self.db.fetchone("SELECT level FROM gb_delegates WHERE chat_id=? AND user_id=?", (chat_id, uid))
        return row["level"] if row else None

    async def perms(self, chat_id: int, uid: int):
        key = (chat_id, uid)
        hit = self.perm_cache.get(key)
        if hit and time.monotonic() - hit[0] < 60:
            return hit[1]
        try:
            perm = await self.client.get_permissions(chat_id, uid)
        except Exception:  # noqa: BLE001
            perm = None
        self.perm_cache[key] = (time.monotonic(), perm)
        return perm

    async def is_admin_target(self, chat_id: int, uid: int) -> bool:
        perm = await self.perms(chat_id, uid)
        return bool(perm and (getattr(perm, "is_admin", False) or getattr(perm, "is_creator", False)))

    # ------------------------------------------------------------------ the work
    async def identify(self, event, *, need_gbot: bool = True):
        """Who is writing and what may he do here? -> dict(level, perm, is_creator, is_admin, rights, uid, chat) or None (not allowed to command).
        need_gbot=False: the caller (`.gai`) has its own switch, so `.gbot off` does not silence it (1.19.4)."""
        await self.ensure()
        chat = int(event.chat_id)
        uid = int(event.sender_id or 0)
        if not uid or uid == self.me or (need_gbot and not await self.enabled(chat)):
            return None
        level = await self.delegate(chat, uid)
        perm = None if level else await self.perms(chat, uid)
        is_creator = bool(perm and getattr(perm, "is_creator", False))
        is_admin = bool(perm and (is_creator or getattr(perm, "is_admin", False)))
        if not (is_admin or level):
            return None
        rights = {r for r in set(RIGHT.values()) if r and perm is not None and getattr(perm, r, False)}
        return {"level": level, "perm": perm, "is_creator": is_creator, "is_admin": is_admin, "rights": rights, "uid": uid, "chat": chat}

    async def handle(self, event) -> None:
        parsed = parse_command(event.raw_text or "")
        if parsed is None:
            return
        who = await self.identify(event)
        if who is None:
            return
        cmd, args = parsed
        replied = await event.get_reply_message() if event.is_reply else None
        await self.run_command(event, cmd, args, replied, who)

    async def run_command(self, event, cmd: str, args: str, replied, who, *, quiet: bool = False) -> bool:
        """Run `cmd args` as the self's own command for the requester `who` (rights are re-checked here, whatever asked for it). True = sent."""
        chat, uid = who["chat"], who["uid"]
        is_creator, is_admin, level = who["is_creator"], who["is_admin"], who["level"]
        if not allowed(cmd, is_admin=is_admin, rights=who["rights"], is_creator=is_creator, level=level):
            if not quiet:
                await self.say(event, "⛔ این کار با دسترسی‌های خودت شدنی نیست.")
            return False
        if cmd in NEEDS_PIN_RIGHT and re.search(r"(?:^|\s)(?:pin|پین)(?:\s|$)", args.lower()) and not (
                is_creator or level or "pin_messages" in who["rights"]):
            if not quiet:
                await self.say(event, "⛔ پین کردن حق Pin Messages می‌خواهد.")
            return False
        if replied is not None and getattr(replied, "action", None) is not None:
            replied = None  # a service message is not a person's message
        explicit = args.split()[0] if args and re.match(r"^(@\w+|-?\d{5,})$", args.split()[0]) else None
        if cmd in NEEDS_REPLY and replied is None:
            if not quiet:
                await self.say(event, f"❓ `{PREFIX}{cmd}` باید روی یک پیام Reply شود.")
            return False
        if cmd in NEEDS_PERSON and replied is None and explicit is None:
            if not quiet:
                await self.say(event, "❓ روی پیام همان فرد Reply کن، یا @username / شناسه‌اش را بنویس.")
            return False
        # --- nobody acts on an admin (except the creator on a non-creator admin: Telegram itself decides that one)
        if not is_creator and level != "god" and cmd in NEEDS_PERSON:      # level `god`: no rule of ours - the real `.ban` / `.mute` and Telegram decide
            victim = int(replied.sender_id) if replied is not None and replied.sender_id else None
            if victim is None and explicit:
                ent = await resolve_target(event, explicit, bare_ok=True)
                victim = int(getattr(ent, "id", 0) or 0) or None
            if victim and await self.is_admin_target(chat, victim):
                if not quiet:
                    await self.say(event, "⛔ روی ادمین‌ها فقط مالک گروه می‌تونه این کار رو بکنه.")
                return False
        # --- flood limits
        now = time.monotonic()
        self.last_by_user[(chat, uid)] = now
        q = self.recent[chat]
        while q and now - q[0] > 60:
            q.popleft()
        if len(q) >= 30:
            if not quiet:
                await self.say(event, "⏳ خیلی سریع شد؛ چند ثانیه صبر کن.")
            return False
        q.append(now)
        # --- run it as the self's own command
        feed = getattr(self.client, "_hapoyi_feed_handlers", None)
        if feed is None:
            if not quiet:
                await self.say(event, "❌ ماژول AI Control بارگذاری نشده؛ اجرای دستور ممکن نیست.")
            return False
        text = f"{PREFIX}{cmd}" + (f" {args}" if args else "")
        try:
            sent = await self.client.send_message(chat, text, reply_to=replied.id if replied is not None else None, link_preview=False, parse_mode=None)
        except Exception as exc:  # noqa: BLE001
            log.info("gbot: cannot send %r: %s", text, exc.__class__.__name__)
            return False
        await feed(sent, _Origin(self.client, chat), replied)
        task = asyncio.get_running_loop().create_task(self._clean(chat, sent.id))
        self.tasks.add(task)
        task.add_done_callback(self.tasks.discard)
        return True

    async def _clean(self, chat: int, msg_id: int) -> None:
        try:
            await asyncio.sleep(4)  # the handlers answer to this message; it goes away after they are done
            await self.client.delete_messages(chat, [msg_id])
        except Exception:  # noqa: BLE001
            pass

    async def say(self, event, text: str, *, keep: float = 8.0):
        """Answer in the chat and remove the note after `keep` seconds (in the background: the handler is never held). Returns the message (or None)."""
        try:
            note = await event.reply(text)
        except Exception:  # noqa: BLE001
            return None
        if keep and keep > 0:
            task = asyncio.get_running_loop().create_task(self._later_delete(note, keep))
            self.tasks.add(task)
            task.add_done_callback(self.tasks.discard)
        return note

    @staticmethod
    async def _later_delete(note, seconds: float) -> None:
        try:
            await asyncio.sleep(seconds)
            await note.delete()
        except Exception:  # noqa: BLE001
            pass


def _panel_text(name: str, level: str | None) -> str:
    state = {"mod": "✅ دسترسی کنترل گروه دارد", "full": "⭐ کنترل کامل دارد (با ارتقا/عزل)",
             "god": "⚡ دسترسی خدا دارد (مثل دستِ خودت؛ حتی روی ادمین‌ها، تا جایی که اکانت تو بتواند)", None: "🚫 دسترسی ندارد"}[level]
    return (f"🛡 <b>دسترسی کنترل گروه</b>\n👤 {html.escape(name)}\nوضعیت: {state}\n\n"
            "بدون ادمین‌شدن در تلگرام، می‌تونه با نوشتن دستور (سکوت، بن، کیک، اخطار، حذف، پین، قفل …) اکانت صاحب رو وادار به انجامش کنه — فقط همین گروه.\n"
            "فقط صاحب اکانت می‌تونه دکمه‌ها رو بزنه.")


def _panel_buttons(token: str):
    return [[Button.inline("✅ کنترل گروه", f"gbd:{token}:mod".encode()), Button.inline("⭐ کنترل کامل", f"gbd:{token}:full".encode())],
            [Button.inline("⚡ خدا", f"gbd:{token}:god".encode()), Button.inline("🚫 گرفتن دسترسی", f"gbd:{token}:off".encode())]]


def setup(client, db):
    ctrl = Controller(client, db)
    client._hapoyi_groupbot = ctrl

    @client.on(events.NewMessage(incoming=True))
    async def on_message(event):
        if not event.is_group or not event.raw_text or getattr(event, "fwd_from", None) or getattr(event.message, "via_bot_id", None):
            return
        try:
            await ctrl.handle(event)
        except Exception:  # noqa: BLE001
            log.exception("gbot failed")

    async def person(event, words: list[str]):
        explicit = None
        for w in words:
            if re.match(r"^(@\w+|-?\d{5,}|tg://\S+|\S*t\.me/\S+)$", w):
                explicit = w
        return await resolve_target(event, clean_target(explicit) if explicit else None)

    async def grant(chat: int, user, level: str | None) -> None:
        uid = int(user.id)
        if level is None:
            await db.execute("DELETE FROM gb_delegates WHERE chat_id=? AND user_id=?", (chat, uid))
        else:
            await db.execute("INSERT INTO gb_delegates(chat_id,user_id,level,name,created_at) VALUES(?,?,?,?,?) "
                             "ON CONFLICT(chat_id,user_id) DO UPDATE SET level=excluded.level, name=excluded.name",
                             (chat, uid, level, display_name(user), datetime.now(timezone.utc).isoformat()))
        if level:
            await db.execute("INSERT INTO gb_chats(chat_id,enabled) VALUES(?,1) ON CONFLICT(chat_id) DO NOTHING", (chat,))

    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}gbot(?:\s+(.*))?$"))
    async def gbot_cmd(event):
        await ctrl.ensure()
        if not event.is_group:
            return await event.reply("❌ فقط در گروه.")
        chat = int(event.chat_id)
        words = (event.pattern_match.group(1) or "status").split()
        word = words[0].lower()
        if word in {"on", "off"}:
            if word == "on":
                perm = await require_group_right(client, chat, "ban_users")
                if not perm.allowed:
                    return await event.reply("❌ برای مدیریت گروه خودت باید ادمین با حق Ban Users باشی: " + perm.reason)
                await db.execute("INSERT INTO gb_chats(chat_id,enabled) VALUES(?,1) ON CONFLICT(chat_id) DO UPDATE SET enabled=1", (chat,))
                return await event.reply("🛡 مدیریت گروه روشن شد: ادمین‌ها و کسانی که بهشون دسترسی دادی می‌تونن دستور بدن و اکانت تو انجام بده.\n\n" + HELP
                                         + f"\n\nدسترسی بدون ادمین‌کردن: Reply + `{PREFIX}delegate`")
            await db.execute("UPDATE gb_chats SET enabled=0 WHERE chat_id=?", (chat,))
            return await event.reply("🛡 مدیریت گروه خاموش شد.")
        if word == "who":
            rows = await db.fetchall("SELECT user_id,level,name FROM gb_delegates WHERE chat_id=?", (chat,))
            if not rows:
                return await event.reply("👥 کسی دسترسی ندارد. (Reply + `" + PREFIX + "delegate`)")
            return await event.reply("👥 دسترسی‌دارها:\n" + "\n".join(f"• {r['name'] or '—'} ({r['user_id']}) — { {'full': '⭐ کامل', 'god': '⚡ خدا'}.get(r['level'], '✅ کنترل') }" for r in rows))
        if word in {"grant", "revoke"}:
            low = {w.lower() for w in words}
            level = "god" if low & {"god", "خدا"} else "full" if "full" in low else "mod"
            user = await person(event, words[1:])
            if user is None:
                return await event.reply("❌ Reply کن یا @username/ID بده.")
            if int(user.id) == ctrl.me:
                return await event.reply("❌ روی خودت لازم نیست.")
            await grant(chat, user, level if word == "grant" else None)
            return await event.reply(f"{'✅' if word == 'grant' else '🚫'} {display_name(user)}: " + ("دسترسی " + {"full": "کامل ", "god": "خدا ⚡ "}.get(level, "کنترل ") + "گرفت." if word == "grant" else "دسترسی‌اش گرفته شد."))
        on = await ctrl.enabled(chat)
        n = len(await db.fetchall("SELECT 1 FROM gb_delegates WHERE chat_id=?", (chat,)))
        await event.reply(f"🛡 مدیریت گروه: {'ON' if on else 'OFF'} • دسترسی‌دار: {n}\n\n{HELP}\n\n`{PREFIX}gbot on|off|who|grant|revoke` | Reply + `{PREFIX}delegate`")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}delegate(?:\s+(\S+))?$"))
    async def delegate_cmd(event):
        await ctrl.ensure()
        if not event.is_group:
            return await event.reply("❌ فقط در گروه.")
        chat = int(event.chat_id)
        perm = await require_group_right(client, chat, "ban_users")
        if not perm.allowed:
            return await event.reply("❌ برای این کار خودت باید ادمین با حق Ban Users باشی: " + perm.reason)
        explicit = event.pattern_match.group(1)
        user = await resolve_target(event, clean_target(explicit) if explicit else None)
        if user is None or getattr(user, "bot", False) or int(user.id) == ctrl.me:
            return await event.reply("❌ روی پیام فرد Reply کن (یا `" + PREFIX + "delegate @username`).")
        await db.execute("INSERT INTO gb_chats(chat_id,enabled) VALUES(?,1) ON CONFLICT(chat_id) DO UPDATE SET enabled=1", (chat,))
        token = secrets.token_urlsafe(6)
        now = time.time()
        for k in [k for k, v in _PANELS.items() if now - v["born"] > 6 * 3600]:
            _PANELS.pop(k, None)
        _PANELS[token] = {"ctrl": ctrl, "chat": chat, "uid": int(user.id), "name": display_name(user), "born": now, "user": user}
        reply_to = event.reply_to_msg_id
        if _bot is None:
            _PANELS.pop(token, None)
            return await event.reply(f"❌ دکمه نیاز به Assistant Bot (BOT_TOKEN) دارد. بدون دکمه: `{PREFIX}gbot grant` (Reply)")
        try:
            username = (await _bot.get_me()).username
            results = await client.inline_query(username, f"gbd {token}")
            if not results:
                raise RuntimeError("no inline results")
            await results[0].click(chat, reply_to=reply_to)
        except Exception as exc:  # noqa: BLE001
            _PANELS.pop(token, None)
            return await event.reply(f"❌ پنل از راه اینلاین ارسال نشد ({exc.__class__.__name__}). در @BotFather برای Assistant Bot دستور /setinline بزن، یا از `{PREFIX}gbot grant` (بدون دکمه) استفاده کن.")
        try:
            await event.delete()
        except Exception:  # noqa: BLE001
            pass


def attach(bot, fleet) -> None:
    global _bot
    _bot = bot

    @bot.on(events.InlineQuery(pattern=r"^gbd\s+(\S+)$"))
    async def on_inline(event):
        panel = _PANELS.get(event.pattern_match.group(1))
        if panel is None or int(event.sender_id) != panel["ctrl"].me:
            return await event.answer([], cache_time=0)
        token = event.pattern_match.group(1)
        level = await panel["ctrl"].delegate(panel["chat"], panel["uid"])
        await event.answer([event.builder.article("🛡 دسترسی کنترل گروه", text=_panel_text(panel["name"], level), parse_mode="html",
                                                  buttons=_panel_buttons(token))], cache_time=0, private=True)

    @bot.on(events.CallbackQuery(pattern=rb"gbd:.*"))
    async def on_click(event):
        try:
            _, token, act = event.data.decode().split(":", 2)
        except ValueError:
            return await event.answer("دکمهٔ نامعتبر", alert=True)
        panel = _PANELS.get(token)
        if panel is None:
            return await event.answer("این پنل منقضی شده؛ دوباره Reply + .delegate بزن.", alert=True)
        c = panel["ctrl"]
        if int(event.sender_id) != c.me:
            return await event.answer("فقط صاحب اکانت می‌تونه این دکمه‌ها رو بزنه ✋", alert=True)
        level = None if act == "off" else act
        if level not in {None, "mod", "full", "god"}:
            return await event.answer("نامعتبر", alert=True)
        uid, chat = panel["uid"], panel["chat"]
        if level is None:
            await c.db.execute("DELETE FROM gb_delegates WHERE chat_id=? AND user_id=?", (chat, uid))
        else:
            await c.db.execute("INSERT INTO gb_delegates(chat_id,user_id,level,name,created_at) VALUES(?,?,?,?,?) "
                               "ON CONFLICT(chat_id,user_id) DO UPDATE SET level=excluded.level, name=excluded.name",
                               (chat, uid, level, panel["name"], datetime.now(timezone.utc).isoformat()))
        await event.answer("انجام شد ✅")
        await event.edit(_panel_text(panel["name"], level), parse_mode="html", buttons=_panel_buttons(token))
