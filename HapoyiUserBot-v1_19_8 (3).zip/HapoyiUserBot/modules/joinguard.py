"""Join verification with a picture quiz (1.18.0).

    .captcha on [5m]            every new member is MUTED AT ONCE; the account posts (via the Assistant Bot's inline mode) 9 numbered pictures:
                                «کدوم یکی «تمساح» است؟». Only that member can answer (buttons 1..9, the answers stay on the buttons).
                                Right -> unmuted. Wrong too often / no answer in time -> the chat's decision (see `fail`).
    .captcha fail mute 1d       the decision: mute <duration> | mute (forever) | mute 23:30 (until that clock time) | ban | ban 1d | kick
    .captcha time 5m            time to answer (30s .. 1h, default 5m)         .captcha tries 2   wrong answers allowed (1..5)
    .captcha math [seconds]     the old way: a tiny sum typed in the chat (no mute first, no Assistant Bot needed)
    .captcha off | status

Needs: this account is admin with «Ban Users»; BOT_TOKEN set and inline mode on for the Assistant Bot (@BotFather /setinline).
The picture is ALWAYS sent by your account through inline (via the bot); the bot never sends it. Without inline the quiz falls back to the old sum so the member is never left muted for nothing.
Pending quizzes live in the database: after a restart the timers are armed again (nobody stays muted forever by accident).
"""
from __future__ import annotations

import asyncio
import html
import io
import json
import logging
import os
import re
import secrets
import time
from typing import Any

from telethon import Button, events, functions, types, utils
from telethon.errors import RPCError

from core.actions import UnsupportedChat, edit_banned
from core.identity import my_id
from core.permissions import require_group_right
from services import joincap as J
from utils.activity import display_name
from utils.rights import ban_rights, mute_rights, open_rights

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
TZ = os.getenv("TIMEZONE", "Asia/Tehran") or "Asia/Tehran"
TABLES = (
    "CREATE TABLE IF NOT EXISTS join_cfg (chat_id INTEGER PRIMARY KEY, mode TEXT NOT NULL DEFAULT 'image', timeout INTEGER NOT NULL DEFAULT 300, "
    "tries INTEGER NOT NULL DEFAULT 2, fail TEXT NOT NULL DEFAULT 'mute', fail_secs INTEGER NOT NULL DEFAULT 0)",
    "CREATE TABLE IF NOT EXISTS join_pending (token TEXT PRIMARY KEY, chat_id INTEGER NOT NULL, user_id INTEGER NOT NULL, name TEXT, answer INTEGER NOT NULL, "
    "files TEXT NOT NULL, label TEXT NOT NULL, wrong TEXT NOT NULL DEFAULT '[]', msg_id INTEGER, deadline REAL NOT NULL, tries INTEGER NOT NULL DEFAULT 2, "
    "fail TEXT NOT NULL DEFAULT 'mute', fail_secs INTEGER NOT NULL DEFAULT 0)",
    "CREATE TABLE IF NOT EXISTS captcha_chats (chat_id INTEGER PRIMARY KEY, timeout INTEGER NOT NULL)",
)
REGISTRY: dict[str, "Controller"] = {}      # token -> the account's controller (the Assistant Bot is shared by every account)
_bot: Any = None


def _mention(uid: int, name: str) -> str:
    return f'<a href="tg://user?id={int(uid)}">{html.escape(name or "کاربر")}</a>'


def caption(row: dict, *, state: str = "ask", extra: str = "") -> str:
    who = _mention(row["user_id"], row["name"])
    if state == "ok":
        return f"✅ {who} تأیید شد و می‌تونه چت کنه."
    if state == "fail":
        return f"❌ {who} تأیید نشد.\n{extra}".strip()
    left = max(0, int(row["deadline"] - time.time()))
    return (f"🛡 {who} خوش اومدی!\n\n🧩 <b>تأیید عضویت</b>\nدر عکس بالا: <b>{J.question(row['label'])}</b>\n"
            f"شمارهٔ درست رو با دکمه‌ها بزن.\n\n⏳ {J.human(left)} وقت داری • {row['tries']} بار فرصت\n🔒 فقط {html.escape(row['name'] or 'همین کاربر')} می‌تونه جواب بده.")


def keyboard(token: str, wrong: list[int], right: int | None = None, done: bool = False):
    rows = J.buttons(token, wrong, right, done=done)
    return [[Button.inline(t, d.encode()) for t, d in row] for row in rows] or None


async def collage_photo(bot, data: bytes):
    """Upload the collage as a REAL Telegram photo and return its InputPhoto.

    Telethon's `builder.photo(raw_bytes)` uploads the bytes with no file name/extension, and Telegram then shows a file called «unnamed»
    (an application that opens in an HTML viewer) instead of a picture. Here the upload gets the name `captcha.jpg`, is registered as a
    photo (InputMediaUploadedPhoto) and the result is checked to really be a photo.
    """
    bio = io.BytesIO(data)
    bio.name = "captcha.jpg"
    handle = await bot.upload_file(bio, file_name="captcha.jpg")
    res = await bot(functions.messages.UploadMediaRequest(types.InputPeerSelf(), media=types.InputMediaUploadedPhoto(handle)))
    photo = getattr(res, "photo", None)
    if not isinstance(photo, types.Photo):
        raise RuntimeError("Telegram did not accept the captcha picture as a photo")
    return utils.get_input_photo(photo)


class Controller:
    def __init__(self, client, db):
        self.client, self.db = client, db
        self.ready = False
        self.pending: dict[str, dict] = {}
        self.timers: dict[str, asyncio.Task] = {}
        self.locks: dict[str, asyncio.Lock] = {}
        self.me = 0

    # ------------------------------------------------------------------ storage
    async def ensure(self) -> None:
        if self.ready:
            return
        self.ready = True
        for stmt in TABLES:
            await self.db.execute(stmt)
        self.me = await my_id(self.client)
        await self.resume()

    async def cfg(self, chat_id: int):
        await self.ensure()
        return await self.db.fetchone("SELECT * FROM join_cfg WHERE chat_id=?", (chat_id,))

    async def save(self, row: dict) -> None:
        await self.db.execute(
            "INSERT INTO join_pending(token,chat_id,user_id,name,answer,files,label,wrong,msg_id,deadline,tries,fail,fail_secs) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) "
            "ON CONFLICT(token) DO UPDATE SET wrong=excluded.wrong, msg_id=excluded.msg_id",
            (row["token"], row["chat_id"], row["user_id"], row["name"], row["answer"], json.dumps(row["files"]), row["label"],
             json.dumps(row["wrong"]), row.get("msg_id"), row["deadline"], row["tries"], row["fail"], row["fail_secs"]))

    async def drop(self, token: str) -> None:
        self.pending.pop(token, None)
        REGISTRY.pop(token, None)
        self.locks.pop(token, None)
        t = self.timers.pop(token, None)
        if t and t is not asyncio.current_task():
            t.cancel()
        await self.db.execute("DELETE FROM join_pending WHERE token=?", (token,))

    async def resume(self) -> None:
        rows = await self.db.fetchall("SELECT * FROM join_pending")
        for r in rows or []:
            d = dict(r)
            d["files"], d["wrong"] = json.loads(d["files"]), json.loads(d["wrong"])
            self.pending[d["token"]] = d
            REGISTRY[d["token"]] = self
            self.arm(d["token"])

    def arm(self, token: str) -> None:
        row = self.pending.get(token)
        if row is None:
            return
        old = self.timers.pop(token, None)
        if old:
            old.cancel()
        self.timers[token] = asyncio.get_running_loop().create_task(self._expire(token, max(0.0, row["deadline"] - time.time())))

    async def _expire(self, token: str, wait: float) -> None:
        try:
            await asyncio.sleep(wait)
            if token in self.pending:
                await self.fail(token, "timeout")
        except asyncio.CancelledError:
            return
        except Exception:  # noqa: BLE001
            log.exception("join quiz expiry failed")

    # ------------------------------------------------------------------ the quiz
    async def start(self, chat_id: int, user) -> None:
        cfg = await self.cfg(chat_id)
        if not cfg or cfg["mode"] != "image":
            return
        uid = int(user.id)
        if uid == self.me or getattr(user, "bot", False):
            return
        if any(p["chat_id"] == chat_id and p["user_id"] == uid for p in self.pending.values()):
            return
        if not (await require_group_right(self.client, chat_id, "ban_users", fresh=False)).allowed:
            return
        try:
            if (await self.client.get_permissions(chat_id, user)).is_admin:
                return  # admins are never asked
        except Exception:  # noqa: BLE001
            pass
        try:
            if await self.db.fetchone("SELECT 1 FROM bl_users WHERE user_id=?", (uid,)):
                return  # the black-list module bans them
        except Exception:  # noqa: BLE001
            pass
        ch = J.make_challenge(J.load_pool())
        if ch is None or _bot is None:
            return await self.fallback(chat_id, user, cfg, muted=False)
        try:
            await edit_banned(self.client, chat_id, user, mute_rights())  # muted from the very first second
        except (RPCError, UnsupportedChat) as exc:
            log.info("join quiz: cannot mute in %s: %s", chat_id, exc.__class__.__name__)
            return
        token = secrets.token_urlsafe(6)
        row = {"token": token, "chat_id": chat_id, "user_id": uid, "name": display_name(user), "answer": ch.answer, "files": ch.files, "label": ch.label,
               "wrong": [], "msg_id": None, "deadline": J.deadline(int(cfg["timeout"])), "tries": int(cfg["tries"]), "fail": cfg["fail"],
               "fail_secs": int(cfg["fail_secs"])}
        self.pending[token] = row
        REGISTRY[token] = self
        try:
            row["msg_id"] = await self.post(chat_id, token, row)
        except Exception as exc:  # noqa: BLE001
            log.info("join quiz: posting failed (%s: %s)", exc.__class__.__name__, exc)
            self.pending.pop(token, None)
            REGISTRY.pop(token, None)
            return await self.fallback(chat_id, user, cfg, muted=True)
        await self.save(row)
        self.arm(token)

    async def post(self, chat_id: int, token: str, row: dict) -> int | None:
        """ONLY through the account itself: an inline query to the Assistant Bot, clicked into the chat (the message shows «via @bot» and is sent
        by the account). The bot never posts anything by itself; when inline does not work the caller falls back to the sum quiz."""
        username = (await _bot.get_me()).username
        results = await self.client.inline_query(username, f"cap {token}")
        if not results:
            raise RuntimeError("inline query returned nothing (is inline mode on in @BotFather?)")
        msg = await results[0].click(chat_id)
        return getattr(msg, "id", None)

    async def fallback(self, chat_id: int, user, cfg, *, muted: bool) -> None:
        """Picture quiz impossible (no Assistant Bot / inline / pictures): never leave the member muted for nothing - old sum quiz."""
        if muted:
            try:
                await edit_banned(self.client, chat_id, user, open_rights())
            except (RPCError, UnsupportedChat):
                pass
        classic = getattr(self.client, "_hapoyi_classic_captcha", None)
        if classic is not None:
            await classic(chat_id, user, min(int(cfg["timeout"]), 600))

    async def answer(self, event, token: str, n: int) -> None:
        row = self.pending.get(token)
        if row is None:
            return await event.answer("این سؤال تموم شده.", alert=True)
        lock = self.locks.setdefault(token, asyncio.Lock())
        async with lock:
            row = self.pending.get(token)
            if row is None:
                return await event.answer("این سؤال تموم شده.", alert=True)
            uid = int(event.sender_id)
            if uid != row["user_id"]:
                return await event.answer("این سؤال برای تو نیست ✋", alert=True)
            if time.time() > row["deadline"]:
                return await event.answer("وقتت تموم شد.", alert=True)
            if n in row["wrong"]:
                return await event.answer("این گزینه رو قبلاً زدی و غلطه.", alert=True)
            if n == row["answer"]:
                await event.answer("درسته ✅")
                return await self.passed(token, event)
            row["wrong"].append(n)
            await self.save(row)
            if len(row["wrong"]) >= row["tries"]:
                await event.answer("اشتباه بود ❌", alert=True)
                return await self.fail(token, "wrong", event)
            left = row["tries"] - len(row["wrong"])
            await event.answer(f"اشتباه بود ❌ — {left} بار دیگه فرصت داری", alert=True)
            try:
                await event.edit(caption(row), parse_mode="html", buttons=keyboard(token, row["wrong"]))
            except Exception:  # noqa: BLE001
                pass

    async def passed(self, token: str, event=None) -> None:
        row = self.pending.get(token)
        if row is None:
            return
        try:
            await edit_banned(self.client, row["chat_id"], row["user_id"], open_rights())
        except (RPCError, UnsupportedChat) as exc:
            log.info("join quiz: unmute failed: %s", exc)
        await self.finish(token, event, "ok", right=row["answer"])

    async def fail(self, token: str, why: str, event=None) -> None:
        row = self.pending.get(token)
        if row is None:
            return
        chat, uid, action, secs = row["chat_id"], row["user_id"], row["fail"], int(row["fail_secs"])
        try:
            if action == "ban":
                await edit_banned(self.client, chat, uid, ban_rights(max(secs, 30) if secs else None))
            elif action == "kick":
                await edit_banned(self.client, chat, uid, ban_rights())
                await edit_banned(self.client, chat, uid, open_rights())
            else:  # mute: for a while (the member is already muted forever - give back the time limit) or forever
                await edit_banned(self.client, chat, uid, mute_rights(max(secs, 30) if secs else None))
        except (RPCError, UnsupportedChat) as exc:
            log.info("join quiz: fail action %s failed: %s", action, exc.__class__.__name__)
        reason = "جواب غلط داد" if why == "wrong" else "در وقت مقرر جواب نداد"
        await self.finish(token, event, "fail", right=row["answer"], extra=f"{reason} ← {J.describe_fail(action, secs)}")

    async def finish(self, token: str, event, state: str, *, right: int, extra: str = "") -> None:
        row = self.pending.get(token)
        if row is None:
            return
        text = caption(row, state=state, extra=extra)
        buttons = keyboard(token, row["wrong"], right=right)
        chat, msg_id = row["chat_id"], row.get("msg_id")
        await self.drop(token)
        shown = False
        if event is not None:
            try:
                await event.edit(text, parse_mode="html", buttons=buttons)  # the answers stay on the buttons for a moment
                shown = True
            except Exception:  # noqa: BLE001
                pass
        asyncio.get_running_loop().create_task(self._tidy(chat, msg_id, text if not shown else None))

    async def _tidy(self, chat: int, msg_id: int | None, note: str | None) -> None:
        """The quiz message goes away after a short while; a timed-out one leaves a one-line note (the account may delete only its own message)."""
        try:
            if note:
                sent = await self.client.send_message(chat, note, parse_mode="html")
                await asyncio.sleep(20)
                await self.client.delete_messages(chat, [m for m in (msg_id, getattr(sent, "id", None)) if m])
            else:
                await asyncio.sleep(25)
                if msg_id:
                    await self.client.delete_messages(chat, [msg_id])
        except Exception:  # noqa: BLE001
            pass

    async def left(self, chat: int, uid: int) -> None:
        for token, row in list(self.pending.items()):
            if row["chat_id"] == chat and row["user_id"] == uid:
                if row.get("msg_id"):
                    try:
                        await self.client.delete_messages(chat, [row["msg_id"]])
                    except Exception:  # noqa: BLE001
                        pass
                await self.drop(token)


def setup(client, db):
    ctrl = Controller(client, db)
    client._hapoyi_joinguard = ctrl

    @client.on(events.ChatAction)
    async def on_join(event):
        if not event.is_group:
            return
        await ctrl.ensure()
        if event.user_left or event.user_kicked:
            try:
                for u in await event.get_users() or []:
                    await ctrl.left(int(event.chat_id), int(u.id))
            except Exception:  # noqa: BLE001
                pass
            return
        if not (event.user_joined or event.user_added):
            return
        try:
            users = await event.get_users()
        except Exception:  # noqa: BLE001
            return
        for user in users or []:
            try:
                await ctrl.start(int(event.chat_id), user)
            except Exception:  # noqa: BLE001
                log.exception("join quiz failed")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}captcha(?:\s+(.*))?$"))
    async def captcha_cmd(event):
        await ctrl.ensure()
        if not event.is_group:
            return await event.reply("❌ فقط در گروه.")
        chat = int(event.chat_id)
        words = (event.pattern_match.group(1) or "status").split()
        word = words[0].lower()
        row = await ctrl.cfg(chat)
        classic = await db.fetchone("SELECT timeout FROM captcha_chats WHERE chat_id=?", (chat,))

        def status() -> str:
            if row:
                return (f"🧩 کپچای عکسی: ON\n• زمان پاسخ: {J.human(row['timeout'])}\n• فرصت: {row['tries']} بار\n"
                        f"• اگر جواب نداد/غلط بود: {J.describe_fail(row['fail'], row['fail_secs'])}\n• عضو جدید از لحظهٔ ورود میوت است تا جواب بده.")
            if classic:
                return f"🧩 کپچای جمع ساده: ON — {classic['timeout']} ثانیه (کیک بعد از شکست)"
            return "🧩 کپچا: OFF"

        usage = (f"\n\n`{PREFIX}captcha on [5m]` | `fail mute 1d|mute|ban|kick|mute 23:30` | `time 5m` | `tries 2` | `math [ثانیه]` | `off`")
        if word == "status":
            return await event.reply(status() + usage)
        if word == "off":
            await db.execute("DELETE FROM join_cfg WHERE chat_id=?", (chat,))
            await db.execute("DELETE FROM captcha_chats WHERE chat_id=?", (chat,))
            return await event.reply("🧩 کپچا خاموش شد.")
        perm = await require_group_right(client, chat, "ban_users")
        if not perm.allowed:
            return await event.reply("❌ برای کپچا باید حق Ban Users داشته باشی: " + perm.reason)

        def seconds(raw: str | None, default: int) -> int | None:
            if not raw:
                return default
            if raw.translate(J._DIGITS).isdigit():
                return int(raw.translate(J._DIGITS))
            v = J.parse_duration(raw)
            return v if v else None

        if word == "math":
            timeout = seconds(words[1] if len(words) > 1 else None, 90)
            if not timeout:
                return await event.reply("❌ زمان نامعتبر.")
            await db.execute("DELETE FROM join_cfg WHERE chat_id=?", (chat,))
            await db.execute("INSERT INTO captcha_chats(chat_id,timeout) VALUES(?,?) ON CONFLICT(chat_id) DO UPDATE SET timeout=excluded.timeout",
                             (chat, max(20, min(timeout, 600))))
            return await event.reply(f"🧩 کپچای جمع ساده روشن شد ({max(20, min(timeout, 600))} ثانیه، بعد کیک).")
        if word == "on":
            timeout = seconds(words[1] if len(words) > 1 else None, J.DEFAULT_TIMEOUT)
            if not timeout:
                return await event.reply("❌ زمان نامعتبر. مثال: `5m` یا `90`")
            timeout = max(J.MIN_TIMEOUT, min(timeout, J.MAX_TIMEOUT))
            await db.execute("DELETE FROM captcha_chats WHERE chat_id=?", (chat,))
            await db.execute("INSERT INTO join_cfg(chat_id,mode,timeout,tries,fail,fail_secs) VALUES(?,?,?,?,?,?) "
                             "ON CONFLICT(chat_id) DO UPDATE SET mode='image', timeout=excluded.timeout", (chat, "image", timeout, J.DEFAULT_TRIES, "mute", 0))
            row = await ctrl.cfg(chat)
            note = "" if _bot is not None else "\n⚠️ BOT_TOKEN تنظیم نیست؛ تا Assistant Bot نباشه به‌جای عکس، جمع ساده می‌پرسم."
            return await event.reply("🧩 کپچای عکسی روشن شد.\n" + status().split("\n", 1)[1] + note
                                     + "\nℹ️ برای ارسال از طریق اینلاین، در @BotFather برای Assistant Bot دستور /setinline رو بزن.")
        if not row:
            return await event.reply("❌ اول `" + PREFIX + "captcha on` رو بزن.")
        if word == "time":
            t = seconds(words[1] if len(words) > 1 else None, 0)
            if not t:
                return await event.reply("❌ مثال: `" + PREFIX + "captcha time 5m`")
            t = max(J.MIN_TIMEOUT, min(t, J.MAX_TIMEOUT))
            await db.execute("UPDATE join_cfg SET timeout=? WHERE chat_id=?", (t, chat))
            return await event.reply(f"⏳ زمان پاسخ: {J.human(t)}")
        if word == "tries":
            n = (words[1] if len(words) > 1 else "").translate(J._DIGITS)
            if not n.isdigit() or not 1 <= int(n) <= 5:
                return await event.reply("❌ عدد ۱ تا ۵. مثال: `" + PREFIX + "captcha tries 2`")
            await db.execute("UPDATE join_cfg SET tries=? WHERE chat_id=?", (int(n), chat))
            return await event.reply(f"🎯 فرصت پاسخ: {int(n)} بار")
        if word == "fail":
            parsed = J.parse_fail(words[1:], TZ)
            if parsed is None:
                return await event.reply("❌ مثال: `" + PREFIX + "captcha fail mute 1d` | `mute` (همیشگی) | `mute 23:30` | `ban` | `ban 7d` | `kick`")
            await db.execute("UPDATE join_cfg SET fail=?, fail_secs=? WHERE chat_id=?", (parsed[0], parsed[1], chat))
            return await event.reply("⚖️ تصمیم نهایی برای کسی که جواب نده/غلط بده: " + J.describe_fail(*parsed))
        await event.reply("❌ زیردستور ناشناخته." + usage)


def attach(bot, fleet) -> None:
    """Inline + callback handlers on the shared Assistant Bot. Only the account that created a quiz may fetch it; only the quizzed member may answer."""
    global _bot
    _bot = bot

    @bot.on(events.InlineQuery(pattern=r"^cap\s+(\S+)$"))
    async def on_inline(event):
        token = event.pattern_match.group(1)
        ctrl = REGISTRY.get(token)
        row = ctrl.pending.get(token) if ctrl else None
        if row is None or int(event.sender_id) != ctrl.me:
            return await event.answer([], cache_time=0)
        try:
            input_photo = await collage_photo(bot, J.render_collage(row["files"]))
            photo = await event.builder.photo(input_photo, text=caption(row), parse_mode="html", buttons=keyboard(token, row["wrong"]))
        except Exception:  # noqa: BLE001
            log.exception("join quiz: could not build the picture result")
            return await event.answer([], cache_time=0)
        await event.answer([photo], cache_time=0, private=True)

    @bot.on(events.CallbackQuery(pattern=rb"cap:.*"))
    async def on_click(event):
        try:
            _, token, n = event.data.decode().split(":", 2)
            n = int(n)
        except ValueError:
            return await event.answer("دکمهٔ نامعتبر", alert=True)
        ctrl = REGISTRY.get(token)
        if ctrl is None:
            return await event.answer("این سؤال تموم شده.", alert=True)
        try:
            await ctrl.answer(event, token, n)
        except Exception:  # noqa: BLE001
            log.exception("join quiz answer failed")
