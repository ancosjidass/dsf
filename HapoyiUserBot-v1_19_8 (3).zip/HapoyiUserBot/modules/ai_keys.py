"""Add AI API keys from Telegram - no .env editing (1.17.1). OWNER account only.

    .apikey add <key>                 provider is detected from the key (gsk_ Groq, csk- Cerebras, AIza Gemini, nvapi- NVIDIA, sk-or- OpenRouter)
    .apikey add <provider> <key> [more keys]      providers: groq cerebras gemini nvidia sambanova mistral openrouter custom
    .apikey custom <base_url> <key> [model1,model2]   any OpenAI-compatible service
    .apikey list                      providers, how many keys, only the LAST 4 characters of the stored ones
    .apikey del <provider> <n|last4|all>              removes stored keys (keys written in .env are changed in .env)
    .apikey test [provider]           checks every key against the service (nothing is generated)

Privacy: the message that contains the key is edited at once (the key disappears from the chat for everybody - still, prefer Saved Messages);
keys are stored encrypted in data/ai_keys.enc (never in the database or in `.backup`), shown only as …abcd, and can only be managed by the
owner (the main account or HAPOYI_OWNER_ID). The AI itself (`.do`) can never run this command.
"""
from __future__ import annotations

import logging
import os
import re

from telethon import events

from core.identity import is_owner
from services import ai, keystore

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
ALIASES = {"google": "gemini", "nim": "nvidia", "or": "openrouter", "samba": "sambanova"}

USAGE = (f"🔑 کلید API بدون دست‌زدن به .env (فقط اکانت اصلی)\n"
         f"`{PREFIX}apikey add <کلید>` — سرویس از روی کلید تشخیص داده می‌شه (gsk_ Groq، csk- Cerebras، AIza Gemini، nvapi- NVIDIA، sk-or- OpenRouter)\n"
         f"`{PREFIX}apikey add <سرویس> <کلید> [کلید دیگر…]` — سرویس‌ها: {', '.join(keystore.providers())}\n"
         f"`{PREFIX}apikey custom <base_url> <کلید> [مدل1,مدل2]` — هر سرویس سازگار با OpenAI\n"
         f"`{PREFIX}apikey list` | `del <سرویس> <شماره|۴ حرف آخر|all>` | `test [سرویس]`\n"
         "💡 بهتره دستور رو در Saved Messages بفرستی؛ پیام حاوی کلید همان لحظه ویرایش و کلید ازش پاک می‌شه.")


def setup(client, db):
    keystore.apply()  # keys saved earlier work from the first second after a restart

    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}(?:apikey|aikey)(?:\s+(.*))?$"))
    async def apikey_cmd(event):
        raw = (event.pattern_match.group(1) or "").strip()
        parts = raw.split()
        word = parts[0].lower() if parts else ""
        # FIRST thing: the key must not stay in the chat.
        if word in {"add", "custom"}:
            await event.edit("🔑 در حال بررسی کلید…")
        if not await is_owner(client):
            return await (event.edit if word in {"add", "custom"} else event.reply)("⛔ فقط اکانت اصلی (مالک) می‌تونه کلید API اضافه یا ببینه.")
        args = parts[1:]

        if word == "add":
            if not args:
                return await event.edit(USAGE)
            first = ALIASES.get(args[0].lower(), args[0].lower())
            groups: dict[str, list[str]] = {}
            if first in keystore.providers():
                if len(args) < 2:
                    return await event.edit(f"❌ کلیدی ننوشتی: `{PREFIX}apikey add {first} <کلید>`")
                groups[first] = args[1:]
            else:
                for k in args:
                    prov = keystore.detect(k)
                    if prov is None:
                        return await event.edit("❌ از روی این کلید نتونستم سرویس رو تشخیص بدم؛ اسمش رو بنویس: "
                                                f"`{PREFIX}apikey add <سرویس> <کلید>` (سرویس‌ها: {', '.join(keystore.providers())}). پیام از کلید پاک شد.")
                    groups.setdefault(prov, []).append(k)
            lines: list[str] = []
            for prov, keys in groups.items():
                good: list[str] = []
                for k in keys:
                    if not keystore.looks_like_key(k):
                        lines.append(f"❌ {prov}: …{k[-4:]} شبیه کلید نیست")
                        continue
                    status, detail = await keystore.check(prov, k) if prov != ai.CUSTOM else ("unknown", "")
                    if status == "invalid":
                        lines.append(f"❌ {prov}: …{k[-4:]} را سرویس قبول نکرد ({detail})")
                    else:
                        good.append(k)
                        if status == "unknown":
                            lines.append(f"⚠️ {prov}: …{k[-4:]} ذخیره شد ولی نتونستم تأییدش کنم ({detail or 'بدون پاسخ'}).")
                if good:
                    try:
                        added, dup = keystore.add(prov, good)
                    except ValueError:
                        lines.append(f"❌ {prov}: حداکثر {keystore.MAX_KEYS_PER_PROVIDER} کلید.")
                        continue
                    label = ai.PROVIDERS[prov].label if prov in ai.PROVIDERS else "Custom"
                    lines.append(f"✅ {label}: {added} کلید اضافه شد" + (f" ({dup} تکراری)" if dup else "") + " — از همین الان استفاده می‌شه.")
            return await event.edit("🔑 " + "\n".join(lines) + "\n🔒 پیام اصلی از کلید پاک شد؛ کلیدها رمزنگاری‌شده ذخیره می‌شن و فقط ۴ حرف آخرشون نشون داده می‌شه.")

        if word == "custom":
            if len(args) < 2 or not args[0].lower().startswith(("http://", "https://")):
                return await event.edit(f"فرمت: `{PREFIX}apikey custom https://example.com/v1 <کلید> [مدل1,مدل2]`")
            keystore.set_custom(args[0], args[1], args[2] if len(args) > 2 else "")
            return await event.edit("🔑 ✅ سرویس Custom تنظیم شد (کلید پاک شد از پیام). `.models` رو ببین؛ اگه مدلی ننوشتی با «🔄 مدل‌های زنده» پیداشون کن.")

        if word == "list":
            rows = keystore.listing()
            if not rows:
                return await event.reply(f"🔑 هنوز کلیدی نیست. `{PREFIX}apikey add <کلید>`")
            lines = [f"• {label}: " + (f"{env_n} از .env" if env_n else "") + (" + " if env_n and mine else "") + (f"{len(mine)} از تلگرام ({', '.join(f'{i}:{m}' for i, m in enumerate(mine, 1))})" if mine else "")
                     for _prov, label, env_n, mine in rows]
            return await event.reply("🔑 کلیدها (فقط ۴ حرف آخر):\n" + "\n".join(lines))

        if word == "del":
            if len(args) < 2:
                return await event.reply(f"فرمت: `{PREFIX}apikey del <سرویس> <شماره|۴ حرف آخر|all>`")
            prov = ALIASES.get(args[0].lower(), args[0].lower())
            if prov not in keystore.providers():
                return await event.reply(f"❌ سرویس ناشناخته. {', '.join(keystore.providers())}")
            n = keystore.remove(prov, args[1])
            return await event.reply(f"🗑 {n} کلید پاک شد." if n else "ℹ️ کلیدی با این مشخصات در کلیدهای تلگرام نبود (کلیدهای .env فقط از خود .env پاک می‌شن).")

        if word == "test":
            wanted = [ALIASES.get(args[0].lower(), args[0].lower())] if args else [p for p in keystore.providers() if ai.provider_keys(p)]
            lines = []
            for prov in wanted:
                for i, k in enumerate(ai.provider_keys(prov), 1):
                    status, detail = await keystore.check(prov, k)
                    lines.append(f"{'✅' if status == 'ok' else '❌' if status == 'invalid' else '⚠️'} {prov} #{i} {ai.mask(k)} {detail}".strip())
            return await event.reply("🔑 تست کلیدها:\n" + ("\n".join(lines) if lines else "کلیدی نیست."))

        return await event.reply(USAGE)
