"""`.mail` - a temporary e-mail panel (1.19.7), for EVERY account that runs the self.

    .mail      posts an inline panel (sent by your account «via» the Assistant Bot) into the current chat:

        📧 Get mail      a new random address on one of the verified domains (`abcd@efgh.example.com`: 4-7 random characters, and a random sub-domain label when the domain answers for sub-domains).
                         No address yet -> you get your first one; you already have one -> you get a NEW one.
        🔄 Update        looks for new mails of the current address (makes the first address when there is none)
        📂 See all inboxes   every address you made, with the number of mails; too many for one Telegram message -> ◀️ ▶️ pages, 🏠 back to this main page
                         a tap on an address shows its mails (◀️ ▶️ again), a tap on a mail shows it fully

The panel belongs to the account that opened it: anybody else who presses its buttons is refused (panel_owner.py).
The mails come from the SMTP receiver of the sandbox server (sandbox_server/tempmail.py); the owner adds the domains with `.sb domain add`.
"""
from __future__ import annotations

import html
import logging
import os
import re
import time
from datetime import datetime
from typing import Any
from zoneinfo import ZoneInfo

from telethon import Button, events
from telethon.errors import MessageNotModifiedError

from core.identity import my_id
from modules.sandbox import Box
from utils import panel_owner as PO

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
TIMEZONE = os.getenv("TIMEZONE", "Asia/Tehran") or "Asia/Tehran"
PER_PAGE = 8                 # addresses per page of «see all inboxes»
MAILS_PER_PAGE = 6
TEXT_BUDGET = 3400           # characters of a page (Telegram: 4096)

_bot: Any = None
_fleet: Any = None


def e(text: Any) -> str:
    return html.escape(str(text))


def clock(ts: float | None = None) -> str:
    try:
        return datetime.fromtimestamp(ts or time.time(), ZoneInfo(TIMEZONE)).strftime("%H:%M:%S")
    except Exception:  # noqa: BLE001
        return time.strftime("%H:%M:%S", time.localtime(ts or time.time()))


def short_sender(raw: str, n: int = 38) -> str:
    raw = re.sub(r"\s+", " ", raw or "").strip() or "؟"
    return raw if len(raw) <= n else raw[: n - 1] + "…"


def data(owner: int, *parts: Any) -> bytes:
    return ("ml:" + PO.to_tag(owner) + ":" + ":".join(str(p) for p in parts)).encode()


def fit_pages(lines: list[str], per: int = PER_PAGE, budget: int = TEXT_BUDGET) -> list[list[int]]:
    """Indexes of `lines` split into pages: at most `per` per page and the page text stays under `budget` characters."""
    pages: list[list[int]] = [[]]
    used = 0
    for i, line in enumerate(lines):
        if pages[-1] and (len(pages[-1]) >= per or used + len(line) + 1 > budget):
            pages.append([])
            used = 0
        pages[-1].append(i)
        used += len(line) + 1
    return pages


def nav_row(owner: int, act: str, page: int, pages: int, *extra: Any) -> list:
    """◀️ 2/5 ▶️ - the arrows only where there is somewhere to go."""
    row = []
    if page > 0:
        row.append(Button.inline("◀️", data(owner, act, *extra, page - 1)))
    row.append(Button.inline(f"{page + 1}/{pages}", data(owner, "noop")))
    if page < pages - 1:
        row.append(Button.inline("▶️", data(owner, act, *extra, page + 1)))
    return row


# ====================================================================== views: (text, buttons)
async def home_view(box: Box, owner: int, note: str = ""):
    items = (await box.mail_list()).get("items", [])
    top = [note] if note else []
    if not items:
        text = "\n".join(["<b>📧 ایمیل موقت</b>", *top, "", "هنوز آدرسی نداری.", "<b>Get mail</b> را بزن تا یک آدرس تصادفی بگیری."])
        return text, [[Button.inline("📧 Get mail", data(owner, "g")), Button.inline("🔄 Update", data(owner, "u"))],
                      [Button.inline("📂 See all inboxes", data(owner, "i", 0))]]
    cur = items[0]
    box_data = await box.mail_inbox(cur["id"], 3, 0)
    msgs = box_data.get("items", [])
    left = max(0, int((cur["expires"] - time.time()) // 60))
    lines = ["<b>📧 ایمیل موقت</b>", *top, "", f"آدرس فعلی (لمس = کپی):\n<code>{e(cur['addr'])}</code>",
             f"📬 {box_data.get('total', 0)} پیام • ⏳ {left // 60} ساعت و {left % 60} دقیقه مانده • 🕐 {clock()}"]
    rows: list = []
    if msgs:
        lines.append("")
        for n, m in enumerate(msgs, 1):
            lines.append(f"<b>{n}.</b> {e(short_sender(m['sender']))}\n    {e((m['subject'] or '')[:70])}")
        rows.append([Button.inline(f"📨 {n}", data(owner, "m", cur["id"], m["id"], "h")) for n, m in enumerate(msgs, 1)])
    else:
        lines += ["", "هنوز پیامی نیامده. بعد از فرستادن ایمیل <b>Update</b> را بزن."]
    rows.append([Button.inline("📧 Get mail", data(owner, "g")), Button.inline("🔄 Update", data(owner, "u"))])
    rows.append([Button.inline(f"📂 See all inboxes ({len(items)})", data(owner, "i", 0))])
    return "\n".join(lines), rows


async def inboxes_view(box: Box, owner: int, page: int = 0):
    items = (await box.mail_list()).get("items", [])
    home = [Button.inline("🏠 برگشت به صفحهٔ اصلی", data(owner, "h"))]
    if not items:
        return "<b>📂 همهٔ inboxها</b>\n\nهنوز آدرسی نداری.", [home]
    lines = [f"{'📬' if it['count'] else '📭'} {it['addr']} ({it['count']})" for it in items]
    pages = fit_pages(lines)
    page = max(0, min(page, len(pages) - 1))
    idx = pages[page]
    text = [f"<b>📂 همهٔ inboxها</b> ({len(items)})  •  صفحهٔ {page + 1} از {len(pages)}", ""]
    rows: list = []
    for i in idx:
        it = items[i]
        text.append(f"{i + 1}. <code>{e(it['addr'])}</code> — {it['count']} پیام")
        rows.append([Button.inline(f"{'📬' if it['count'] else '📭'} {it['addr']} ({it['count']})"[:60], data(owner, "a", it["id"], 0))])
    if len(pages) > 1:
        rows.append(nav_row(owner, "i", page, len(pages)))
    rows.append(home)
    return "\n".join(text), rows


async def address_view(box: Box, owner: int, aid: int, page: int = 0):
    back = [Button.inline("⬅️ همهٔ inboxها", data(owner, "i", 0)), Button.inline("🏠 صفحهٔ اصلی", data(owner, "h"))]
    try:
        res = await box.mail_inbox(aid, MAILS_PER_PAGE, page * MAILS_PER_PAGE)
    except RuntimeError:
        return "این inbox پیدا نشد (منقضی یا پاک شده).", [back]
    total = int(res.get("total", 0))
    pages = max(1, -(-total // MAILS_PER_PAGE))
    if page >= pages:                                    # the list shrank: go to the last page
        return await address_view(box, owner, aid, pages - 1)
    addr = res["address"]["addr"]
    lines = [f"<b>📬 inbox</b>\n<code>{e(addr)}</code>", f"{total} پیام • صفحهٔ {page + 1} از {pages}", ""]
    rows: list = []
    if not res["items"]:
        lines.append("خالی است.")
    for n, m in enumerate(res["items"], 1):
        lines.append(f"<b>{n}.</b> {e(short_sender(m['sender']))} • {clock(m['ts'])}\n    {e((m['subject'] or '')[:70])}")
    if res["items"]:
        rows.append([Button.inline(f"📨 {n}", data(owner, "m", aid, m["id"], page)) for n, m in enumerate(res["items"], 1)])
    if pages > 1:
        rows.append(nav_row(owner, "a", page, pages, aid))
    rows.append([Button.inline("🗑 پاک‌کردن این inbox", data(owner, "d", aid))])
    rows.append(back)
    return "\n".join(lines), rows


async def message_view(box: Box, owner: int, aid: int, mid: int, origin: str):
    back_to = data(owner, "h") if origin == "h" else data(owner, "a", aid, int(origin) if origin.isdigit() else 0)
    try:
        m = await box.mail_message(aid, mid)
    except RuntimeError:
        return "این پیام پیدا نشد.", [[Button.inline("⬅️ برگشت", back_to)]]
    body = (m.get("body") or "").strip() or "(متن ندارد)"
    head = [f"<b>📨 {e((m.get('subject') or '')[:150])}</b>", f"از: {e(short_sender(m.get('sender', ''), 80))}", f"🕐 {clock(m.get('ts'))}"]
    if m.get("attachments"):
        head.append("📎 " + e(", ".join(m["attachments"][:5])) + " (پیوست‌ها نگه داشته نمی‌شوند)")
    room = TEXT_BUDGET - sum(len(x) for x in head) - 40
    cut = body if len(body) <= room else body[:room] + "…"
    return "\n".join(head) + "\n\n" + e(cut), [[Button.inline("⬅️ برگشت", back_to), Button.inline("🏠 صفحهٔ اصلی", data(owner, "h"))]]


def not_ready_text(why: str) -> str:
    return "❌ " + why


# ====================================================================== the clicks
async def on_click(event):
    try:
        _, tag, *rest = event.data.decode().split(":")
    except (ValueError, UnicodeDecodeError):
        return await event.answer("دکمهٔ نامعتبر", alert=True)
    owner = PO.from_tag(tag)
    if owner is None or int(owner) != int(event.sender_id):          # a panel of another account (also one that runs the self): not yours
        return await event.answer("⛔ این پنل را کس دیگری باز کرده؛ برای خودت بنویس .mail", alert=True)
    if _fleet is None or _fleet.runtime_for_user(event.sender_id) is None:
        return await event.answer("⛔ این پنل فقط برای صاحب سلف است.", alert=True)
    act = rest[0] if rest else "h"
    if act == "noop":
        return await event.answer()
    box = Box(f"u{int(event.sender_id)}")
    try:
        if act == "g":
            new = await box.mail_new()
            text, rows = await home_view(box, owner, f"🆕 آدرس جدید ساخته شد: <code>{e(new['addr'])}</code>")
        elif act == "u":
            items = (await box.mail_list()).get("items", [])
            note = ""
            if not items:
                new = await box.mail_new()
                note = f"🆕 آدرس جدید ساخته شد: <code>{e(new['addr'])}</code>"
            text, rows = await home_view(box, owner, note)
        elif act == "h":
            text, rows = await home_view(box, owner)
        elif act == "i":
            text, rows = await inboxes_view(box, owner, int(rest[1]) if len(rest) > 1 else 0)
        elif act == "a" and len(rest) >= 2:
            text, rows = await address_view(box, owner, int(rest[1]), int(rest[2]) if len(rest) > 2 else 0)
        elif act == "m" and len(rest) >= 4:
            text, rows = await message_view(box, owner, int(rest[1]), int(rest[2]), rest[3])
        elif act == "d" and len(rest) >= 2:
            await box.mail_delete(int(rest[1]))
            text, rows = await inboxes_view(box, owner, 0)
        else:
            return await event.answer("دکمهٔ نامعتبر", alert=True)
    except RuntimeError as exc:
        msg = str(exc)
        if "409" in msg:
            msg = "هیچ دامنهٔ ایمیل‌داری نیست؛ صاحب سلف `.sb domain add` بزند (MX باید به سرور برسد) یا `.sb domain mail <دامنه> on`."
        return await event.answer("❌ " + msg[:180], alert=True)
    except Exception as exc:  # noqa: BLE001
        log.exception("mail panel")
        return await event.answer(f"❌ {exc.__class__.__name__}", alert=True)
    try:
        await event.edit(text[:4000], parse_mode="html", buttons=rows, link_preview=False)
        await event.answer()
    except MessageNotModifiedError:
        await event.answer("تغییری نیست ✅")


async def on_inline(event):
    """`@YourBot mail` (made by `.mail`): the main page - only for an account that runs the self."""
    rt = _fleet.runtime_for_user(event.sender_id) if _fleet is not None else None
    if rt is None:
        return await event.answer([], cache_time=0)
    owner = int(event.sender_id)
    try:
        text, rows = await home_view(Box(f"u{owner}"), owner)
    except Exception as exc:  # noqa: BLE001
        text, rows = not_ready_text(f"sandbox در دسترس نیست ({exc.__class__.__name__})"), None
    await event.answer([event.builder.article("📧 ایمیل موقت", text=text, parse_mode="html", buttons=rows, description="Get mail • Update • See all inboxes")],
                       cache_time=0, private=True)


def attach(bot, fleet) -> None:
    """Called by modules/ui.attach (one Assistant Bot for the whole fleet)."""
    global _bot, _fleet
    _bot, _fleet = bot, fleet
    bot.add_event_handler(on_click, events.CallbackQuery(pattern=rb"ml:.*"))
    bot.add_event_handler(on_inline, events.InlineQuery(pattern=r"^mail\s*$"))


# ====================================================================== the command (every account)
def setup(client, db):
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}mail$"))
    async def mail_cmd(event):
        url, token = Box.configured()
        if not url or not token:
            return await event.reply("❌ sandbox تنظیم نشده (`SANDBOX_URL` / `SANDBOX_TOKEN` در .env)؛ `.mail` از سرور sandbox ایمیل می‌گیرد.")
        if _bot is None:
            return await event.reply("❌ منوی دکمه‌ای فعال نیست؛ در .env مقدار BOT_TOKEN را تنظیم کن و سلف را ری‌استارت کن.")
        me = int(await my_id(client))
        box = Box(f"u{me}")
        try:
            info = await box.mail_list()
        except Exception as exc:  # noqa: BLE001
            return await event.reply(f"❌ به sandbox وصل نشد: {exc.__class__.__name__} {str(exc)[:120]}")
        if not info.get("domains"):
            return await event.reply("❌ هیچ دامنهٔ ایمیل‌داری ثبت نشده. صاحب سلف با `.sb domain add example.com` یک دامنه می‌گذارد (MX آن باید به سرور برسد)؛ اگر دامنه را قبلاً گذاشته ولی MX سبز نشد: `.sb domain check example.com` را بزن تا دلیلش را ببینی، یا `.sb domain mail example.com on` برای روشن‌کردن اجباری.")
        posted = False
        try:
            from utils.inline_launch import post_inline

            await post_inline(client, _bot, "mail", event.chat_id, getattr(event, "reply_to_msg_id", None))
            posted = True
        except Exception as exc:  # noqa: BLE001
            log.info("inline mail failed (%s: %s); falling back to bot.send_message", exc.__class__.__name__, exc)
        if not posted:
            try:
                text, rows = await home_view(box, me)
                await _bot.send_message(event.chat_id, text, parse_mode="html", buttons=rows, link_preview=False)
                posted = True
            except Exception as exc:  # noqa: BLE001
                return await event.reply(f"❌ Assistant Bot نتوانست پنل را بفرستد ({exc.__class__.__name__}). در @BotFather برای بات /setinline بزن.")
        if posted:
            try:
                await event.delete()
            except Exception:  # noqa: BLE001
                pass
