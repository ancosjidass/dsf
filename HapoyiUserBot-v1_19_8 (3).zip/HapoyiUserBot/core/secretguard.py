"""Security layer of the AI (1.19.6).

1. `redact(text)`   every AI answer passes it: the values of the secrets of this bot (bot token, API keys / hash, sandbox token, string sessions, passwords ...) and anything
                    that LOOKS like one (a Telegram bot token, sk-/gsk_/AIza keys, a long session string, private-key blocks) become «⟦hidden⟧» - even if somebody talked the model into
                    printing them.
2. `probe(text)`    a request from somebody who is NOT the owner (a group admin / delegate writing to «ربات …») that asks for the source code, tokens, the .env, sessions, the
                    prompt / instructions, a shell command (rm -rf, cd /, sudo, curl | sh ...) or tries the classic «ignore the previous instructions» is refused before the AI sees it.
The owner's own account is trusted (it types the commands itself). Hard limits that do not depend on this file: the group AI can only produce group commands (no shell exists for it),
and the sandbox is a separate container without any secret (sandbox_server/).
"""
from __future__ import annotations

import os
import re

MASK = "⟦hidden⟧"
ENV_HINT = re.compile(r"(TOKEN|SECRET|PASSWORD|PASSWD|API_?KEY|API_?HASH|_HASH|PRIVATE|CREDENTIAL|SESSION_?STRING|STRING_?SESSION|DATABASE_URL|DSN|COOKIE|LICENSE_?KEY|ENCRYPTION|FERNET|SALT)", re.I)
SKIP_VALUES = {"true", "false", "none", "null", "yes", "no", "on", "off"}

PATTERNS = (
    re.compile(r"\b\d{8,10}:[A-Za-z0-9_-]{30,}\b"),                                     # Telegram bot token
    re.compile(r"\b(?:sk|gsk|nvapi|xai|hf|ghp|gho|github_pat|pplx|r8|AIza|csk)[-_][A-Za-z0-9_\-]{16,}"),   # common API keys
    re.compile(r"\bAIza[0-9A-Za-z_\-]{30,}\b"),
    re.compile(r"\b1[A-Za-z0-9+/_=-]{220,}\b"),                                          # Telethon string session
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?(?:-----END [A-Z ]*PRIVATE KEY-----|$)", re.S),
    re.compile(r"(?i)\b(?:bearer|authorization:?\s*bearer)\s+[A-Za-z0-9._\-]{20,}"),
)


def secret_values() -> list[str]:
    """The secrets of this process: env values whose NAME says secret, plus the AI keys in use."""
    out: set[str] = set()
    for name, value in os.environ.items():
        v = (value or "").strip()
        if not v or v.lower() in SKIP_VALUES or len(v) < 8 or not ENV_HINT.search(name):
            continue
        if "SESSION" in name.upper() and len(v) < 40:                                    # a session NAME / path is not a secret
            continue
        if not (re.search(r"\d", v) or len(v) >= 24):                                    # a plain word / path
            continue
        out.add(v)
    try:
        from services import ai  # noqa: PLC0415

        for entry in ai.load_chain():
            out.update(k for k in (entry.key, *entry.keys) if k and len(k) >= 8)
    except Exception:  # noqa: BLE001
        pass
    return sorted(out, key=len, reverse=True)


def redact(text: str | None) -> str | None:
    if not text:
        return text
    for value in secret_values():
        if value in text:
            text = text.replace(value, MASK)
    for pat in PATTERNS:
        text = pat.sub(MASK, text)
    return text


# ------------------------------------------------------------------ requests of people who are not the owner
_ASKS = (
    r"(?:source ?code|سورس|کد ?(?:ربات|سلف|بات|برنامه)|کدهای? (?:ربات|سلف)|repo(?:sitory)?|ریپو|فایل(?:‌| )?های? (?:ربات|سلف|سرور)|zip ?(?:ربات|سلف))",
    r"(?:bot ?token|توکن|token\b|api[ _-]?(?:key|hash|id)|کلید ?(?:api|ای ?پی ?آی|ربات|سلف)|\.env\b|env ?file|فایل ?env|environ(?:ment)?|string ?session|session ?string|سشن|سِشن|session file)",
    r"(?:system ?prompt|سیستم ?پرامپت|پرامپت ?(?:سیستم|اصلی)?|prompt|دستور(?:ات)? ?(?:سیستم|اولیه|داخلی)|instructions?|مستندات|your (?:rules|instructions|config)|قوانین ?(?:خودت|داخلی))",
    r"(?:رمز(?:ِ)? ?(?:ربات|اکانت|سلف|سرور|عبور)|پسورد|password|passwd|credentials?|اطلاعات ?(?:ورود|محرمانه)|secret)",
)
_SHELL = (
    r"\brm\s+-[a-z]*[rf]", r"\bsudo\b", r"\bchmod\b", r"\bchown\b", r"\bmkfs\b", r"\bdd\s+if=", r"\bshutdown\b", r"\breboot\b", r"\bkill\s+-9", r"\bpkill\b", r"\bkillall\b",
    r"(?:^|[\s;&|(])cd\s+(?:/|~|\.\.)", r"(?:^|[\s;&|(])(?:cat|less|more|head|tail|strings|xxd|base64|tar|zip|scp|rsync)\s+[~/.]\S*", r"\b(?:curl|wget)\b[^\n]*\|\s*(?:ba|z)?sh\b",
    r"\b(?:curl|wget|nc|ncat|socat)\s+\S+", r"/etc/(?:passwd|shadow|hosts)", r"/proc/\S+/environ", r"/dev/(?:tcp|udp)/", r"\bos\.system\b|\bsubprocess\b|\beval\s*\(|\bexec\s*\(|\b__import__\b",
    r"\bpython3?\s+-c\b", r"\bbash\s+-c\b", r"\bsh\s+-c\b", r"\bnode\s+-e\b", r"\bdocker\b", r"\bgit\s+(?:clone|push|remote)", r"\bpip\s+install\b", r"\bnpm\s+(?:i|install)\b",
    r"(?:اجرا|run|execute)\s+(?:کن\s+)?(?:این\s+)?(?:دستور|کامند|command|کد|code|اسکریپت|script)\s+(?:ترمینال|شل|shell|bash|لینوکس|linux)",
    r"(?:ترمینال|terminal|shell|شل|bash)\b",
)
_INJECT = (
    r"ignore (?:all |any |the )?(?:previous|above|prior|earlier) (?:instructions?|rules?|prompts?)", r"disregard (?:all |any |the )?(?:previous|above|prior) ",
    r"(?:forget|override|bypass|reset) (?:all |your |the )?(?:previous |prior |earlier )?(?:instructions?|rules?|restrictions?|guidelines?|safety)",
    r"(?:دستورات|دستور|قوانین|قانون)(?:‌| )?(?:های )?(?:قبلی|بالا|اولیه|قبل)(?:‌| )?(?:ات)?(?: رو| را)? ?(?:نادیده|فراموش|رد) ?(?:بگیر|کن)", r"(?:نادیده ?بگیر|فراموش ?کن) (?:همه )?(?:دستورات|قوانین)",
    r"you are now (?:in )?(?:developer|dev|dan|god|admin|root|unrestricted)", r"\b(?:developer|jailbreak|dan|god) ?mode\b", r"(?:حالت|مود) ?(?:توسعه|دولوپر|جیلبریک|بدون ?محدودیت)",
    r"act as (?:a )?(?:linux|unix|root|terminal|shell|bash)", r"(?:مثل|مانند|بشو|باش) (?:یه |یک )?(?:ترمینال|شل|لینوکس|root|روت)", r"\bsystem\s*:\s*you\b", r"<\|?(?:im_start|system)\|?>",
)
ASK_RE = re.compile("|".join(_ASKS), re.I)
SHELL_RE = re.compile("|".join(_SHELL), re.I)
INJECT_RE = re.compile("|".join(_INJECT), re.I)
REFUSAL = "🔒 این درخواست مجاز نیست؛ من فقط کارهای مدیریت گروه رو انجام می‌دم."


def probe(text: str | None) -> str | None:
    """Why a request of a NON-owner must be refused ('shell' | 'secret' | 'inject'), or None when it is fine."""
    t = (text or "").strip()
    if not t:
        return None
    if INJECT_RE.search(t):
        return "inject"
    if SHELL_RE.search(t):
        return "shell"
    if ASK_RE.search(t):
        return "secret"
    return None


# ------------------------------------------------------------------ commands an AI (owner's .do included) is never allowed to send
FORBIDDEN_FOR_AI = {
    "apikey": "کلیدهای API", "lic": "لایسنس‌ها", "restore": "بازیابی دیتابیس", "sb": "sandbox", "deactivate": "خاموش‌کردن سلف", "protect": "تنظیم محافظ اکانت",
    "aiknow": "دانش AI", "env": "تنظیمات محرمانه",
}

# ------------------------------------------------------------------ shell commands the AI may not run even inside the sandbox
from sandbox_server.guardrules import DANGER_RE, dangerous_command  # noqa: E402,F401  (one list for the bot and for the server)
