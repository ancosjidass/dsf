"""Join verification (1.18.0) - the pure part: picture quiz, button states, fail-action parsing. No Telegram in here.

A new member is muted at once; the account posts (through the Assistant Bot's inline mode) ONE collage of 9 pictures numbered 1..9
and asks «کدوم یکی «تمساح» است؟». Only that member can answer; every answer is shown on the buttons (❌ wrong, ✅ right).
Right answer -> unmuted. Wrong answers over the limit / no answer in time -> the decision of the chat (mute for a while, mute forever, ban, kick).

The 20 default pictures are in assets/captcha/ (labels.json: file -> Persian name). Put more pictures there (and a line in labels.json) - any count >= 9 works.
"""
from __future__ import annotations

import io
import json
import random
import re
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

ASSET_DIR = Path(__file__).resolve().parent.parent / "assets" / "captcha"
GRID = 9
CELL = 176
DEFAULT_TIMEOUT = 300          # 5 minutes
DEFAULT_TRIES = 2
MIN_TIMEOUT, MAX_TIMEOUT = 30, 3600
FAIL_ACTIONS = ("mute", "ban", "kick")
_DUR = re.compile(r"^(\d+)\s*(s|sec|m|min|h|hr|d|w)$", re.I)
_CLOCK = re.compile(r"^(\d{1,2})[:٫.](\d{2})$")
_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
_UNIT = {"s": 1, "sec": 1, "m": 60, "min": 60, "h": 3600, "hr": 3600, "d": 86400, "w": 604800}
_WORDS = {"همیشه": 0, "دائمی": 0, "دایمی": 0, "forever": 0, "perm": 0, "permanent": 0, "always": 0}


@dataclass
class Picture:
    file: str
    label: str
    aliases: tuple[str, ...] = ()


@dataclass
class Challenge:
    files: list[str]                 # 9 file names in grid order
    answer: int                      # 1-based position of the right picture
    label: str                       # Persian name of the right picture
    picked: list[int] = field(default_factory=list)   # wrong choices so far (positions)


def load_pool(directory: Path | str | None = None) -> list[Picture]:
    d = Path(directory) if directory else ASSET_DIR
    try:
        labels = json.loads((d / "labels.json").read_text("utf-8"))
    except (OSError, ValueError):
        labels = {}
    pool: list[Picture] = []
    for p in sorted(d.glob("*")) if d.is_dir() else []:
        if p.suffix.lower() not in {".png", ".jpg", ".jpeg", ".webp"}:
            continue
        info = labels.get(p.name) or {}
        label = str(info.get("fa") or "").strip() if isinstance(info, dict) else str(info).strip()
        if not label:
            continue  # a picture without a name cannot be asked about
        al = info.get("aliases", []) if isinstance(info, dict) else []
        pool.append(Picture(p.name, label, tuple(str(a) for a in al)))
    return pool


def make_challenge(pool: list[Picture], rng: random.Random | None = None) -> Challenge | None:
    r = rng or random
    labels = {p.label for p in pool}
    if len(pool) < GRID or len(labels) < GRID:
        return None
    chosen: list[Picture] = []
    seen: set[str] = set()
    for p in r.sample(pool, len(pool)):  # never two pictures with the same name (the question would have two answers)
        if p.label not in seen:
            chosen.append(p)
            seen.add(p.label)
        if len(chosen) == GRID:
            break
    target = r.choice(chosen)
    return Challenge([p.file for p in chosen], chosen.index(target) + 1, target.label)


def question(label: str) -> str:
    return f"کدوم یکی «{label}» است؟"


def render_collage(files: list[str], directory: Path | str | None = None) -> bytes:
    """3x3 collage, each cell carries its number (1..9) in a corner. JPEG bytes."""
    from PIL import Image, ImageDraw, ImageFont  # noqa: PLC0415

    d = Path(directory) if directory else ASSET_DIR
    gap = 6
    side = 3 * CELL + 4 * gap
    sheet = Image.new("RGB", (side, side), "#ffffff")
    font = None
    for name in ("DejaVuSans-Bold.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "arialbd.ttf", "Arial Bold.ttf"):
        try:
            font = ImageFont.truetype(name, 34)
            break
        except OSError:
            continue
    if font is None:
        try:
            font = ImageFont.load_default(size=34)  # Pillow >= 10.1: scalable built-in font, the numbers stay big
        except TypeError:
            font = ImageFont.load_default()
    draw = ImageDraw.Draw(sheet)
    for i, name in enumerate(files[:GRID]):
        col, row = i % 3, i // 3
        x, y = gap + col * (CELL + gap), gap + row * (CELL + gap)
        with Image.open(d / name) as im:
            sheet.paste(im.convert("RGB").resize((CELL, CELL)), (x, y))
        draw.ellipse((x + 6, y + 6, x + 52, y + 52), fill="#1f2937")
        draw.text((x + 29, y + 29), str(i + 1), fill="#ffffff", font=font, anchor="mm")
    out = io.BytesIO()
    sheet.save(out, "JPEG", quality=86)
    return out.getvalue()


def buttons(token: str, wrong: list[int], right: int | None = None, *, done: bool = False) -> list[list[tuple[str, str]]]:
    """(label, callback data) rows for the 3x3 keyboard. Wrong picks show ❌; after the end the right one shows ✅. None when finished."""
    if done:
        return []
    rows = []
    for r in range(3):
        row = []
        for c in range(3):
            n = r * 3 + c + 1
            mark = "❌" if n in wrong else ("✅" if right == n else str(n))
            row.append((mark, f"cap:{token}:{n}"))
        rows.append(row)
    return rows


def parse_duration(raw: str) -> int | None:
    """'30s' '10m' '2h' '1d' '1w' -> seconds; 'همیشه'/'forever' -> 0 (= no end); a clock time '17:30' -> seconds until the next 17:30
    (Asia/Tehran unless tz given by the caller through parse_until); anything else -> None."""
    t = (raw or "").strip().lower().translate(_DIGITS)
    if t in _WORDS:
        return 0
    m = _DUR.match(t)
    if m:
        return int(m.group(1)) * _UNIT[m.group(2).lower()]
    return None


def seconds_until_clock(raw: str, tz: str = "Asia/Tehran", now: datetime | None = None) -> int | None:
    m = _CLOCK.match((raw or "").strip().translate(_DIGITS))
    if not m:
        return None
    h, mi = int(m.group(1)), int(m.group(2))
    if h > 23 or mi > 59:
        return None
    n = now or datetime.now(ZoneInfo(tz))
    target = n.replace(hour=h, minute=mi, second=0, microsecond=0)
    if target <= n:
        target += timedelta(days=1)
    return max(1, int((target - n).total_seconds()))


def parse_fail(words: list[str], tz: str = "Asia/Tehran") -> tuple[str, int] | None:
    """['mute','1d'] -> ('mute', 86400) | ['mute'] -> ('mute', 0 = forever) | ['ban'] | ['kick'] | ['mute','23:30'] (until that time).
    Persian words are accepted too (میوت / سکوت / بن / کیک / اخراج)."""
    if not words:
        return None
    alias = {"mute": "mute", "میوت": "mute", "سکوت": "mute", "ban": "ban", "بن": "ban", "kick": "kick", "کیک": "kick", "اخراج": "kick"}
    action = alias.get(words[0].lower())
    if action is None:
        return None
    secs = 0
    if len(words) > 1:
        arg = words[1]
        d = parse_duration(arg)
        if d is None:
            d = seconds_until_clock(arg, tz)
        if d is None:
            return None
        secs = d
    if action == "kick":
        secs = 0
    return action, secs


def describe_fail(action: str, secs: int) -> str:
    if action == "kick":
        return "اخراج (می‌تونه دوباره بیاد)"
    if action == "ban":
        return "بن " + (human(secs) if secs else "همیشگی")
    return "میوت " + (human(secs) if secs else "همیشگی")


def human(secs: int) -> str:
    secs = int(secs)
    for unit, name in ((604800, "هفته"), (86400, "روز"), (3600, "ساعت"), (60, "دقیقه")):
        if secs >= unit:
            n = secs / unit
            return f"{int(n) if n == int(n) else round(n, 1)} {name}"
    return f"{secs} ثانیه"


def deadline(timeout: int, now: float | None = None) -> float:
    return (now if now is not None else time.time()) + int(timeout)
