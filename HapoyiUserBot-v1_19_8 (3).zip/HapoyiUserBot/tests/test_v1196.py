"""1.19.6: a command sent by the AI / «ربات ...» / `.gai do` reaches its handler at once (no per-handler Telegram lookups -> no FloodWait stall)."""
from __future__ import annotations

import asyncio
import datetime
import pathlib
import re
import sys
import tempfile

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from telethon import TelegramClient, events  # noqa: E402
from telethon.tl import types as tl  # noqa: E402

from tests.test_v1170 import make_db  # noqa: E402


class CountingOrigin:
    def __init__(self):
        self.chat_id = -1000000001001      # == the chat_id of PeerChannel(1001)
        self.calls = {"chat": 0, "input_chat": 0, "sender": 0, "input_sender": 0}

    async def get_chat(self):
        self.calls["chat"] += 1
        return tl.Channel(id=1001, title="g", photo=tl.ChatPhotoEmpty(), date=datetime.datetime.now(datetime.timezone.utc), access_hash=1)

    async def get_input_chat(self):
        self.calls["input_chat"] += 1
        return tl.InputPeerChannel(channel_id=1001, access_hash=1)

    async def get_sender(self):
        self.calls["sender"] += 1
        return tl.User(id=5, first_name="Me")

    async def get_input_sender(self):
        self.calls["input_sender"] += 1
        return tl.InputPeerSelf()


def test_fed_command_does_not_look_the_chat_up_once_per_handler():
    from modules import ai_agent

    real = TelegramClient(tempfile.mktemp(), 1, "a" * 32)
    ran = []
    for i in range(150):                       # the real bot has ~200 command handlers; none of them may cost a network round trip
        real.add_event_handler(lambda ev, i=i: ran.append(i), events.NewMessage(outgoing=True, pattern=rf"^\.nomatch{i}$"))

    @real.on(events.NewMessage(outgoing=True, pattern=rf"^{re.escape('.')}mute\b.*$"))
    async def mute(event):
        ran.append(("mute", event.raw_text))

    real._hapoyi_me_id = 5
    db = asyncio.run(make_db())
    ai_agent.setup(real, db)
    origin = CountingOrigin()

    async def run():
        sent = tl.Message(id=9, peer_id=tl.PeerChannel(1001), message=".mute 1h", out=True,
                          date=datetime.datetime.now(datetime.timezone.utc), from_id=tl.PeerUser(5))
        n = await real._hapoyi_feed_handlers(sent, origin, None)
        assert n == 1
        await asyncio.sleep(0.2)
        assert ran == [("mute", ".mute 1h")]
        assert all(v <= 1 for v in origin.calls.values()), origin.calls      # before: 150+ calls of every kind
        await real._hapoyi_feed_handlers(sent, origin, None)                  # the second command of the same chat: served from the cache
        assert all(v <= 1 for v in origin.calls.values()), origin.calls

    asyncio.run(run())
