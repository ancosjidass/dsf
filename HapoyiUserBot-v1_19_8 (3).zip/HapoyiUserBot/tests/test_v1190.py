"""1.19.0: `.sched` (clock times, polls, reply, pin), `.modai` (spam / swearing, log), `.gai` (the group's AI), docs for `.do`."""
from __future__ import annotations

import asyncio
import json
import pathlib
import sys
import time
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

import pytest  # noqa: E402

from services import aiagent as A  # noqa: E402
from services import knowledge as K  # noqa: E402
from services import modcheck as M  # noqa: E402
from services import schedparse as S  # noqa: E402
from tests.test_regressions import FakeClient, _find  # noqa: E402
from tests.test_v1170 import FE, Script, dispatch, make_db  # noqa: E402
from tests.test_v1180 import GEvent, _adm, _gb_env  # noqa: E402

UTC = timezone.utc


# ================================================================== schedparse
def _now(h=16, m=0):
    return datetime(2026, 10, 22, h, m, tzinfo=UTC)          # Tehran = UTC+3:30 -> 19:30 / 20:00


def test_when_durations_clock_tomorrow_and_dates():
    when, rest = S.parse_when(["10m", "pin", "سلام"], "UTC", _now())
    assert when == _now() + timedelta(minutes=10) and rest == ["pin", "سلام"]
    when, rest = S.parse_when(["17:30", "x"], "UTC", _now())
    assert when == datetime(2026, 10, 22, 17, 30, tzinfo=UTC) and rest == ["x"]
    when, _ = S.parse_when(["۱۵:۳۰", "x"], "UTC", _now())                      # already past today -> tomorrow
    assert when == datetime(2026, 10, 23, 15, 30, tzinfo=UTC)
    when, rest = S.parse_when(["ساعت", "18", "پین"], "UTC", _now())
    assert when == datetime(2026, 10, 22, 18, 0, tzinfo=UTC) and rest == ["پین"]
    when, rest = S.parse_when(["فردا", "09:15", "متن"], "UTC", _now())
    assert when == datetime(2026, 10, 23, 9, 15, tzinfo=UTC) and rest == ["متن"]
    when, _ = S.parse_when(["tomorrow", "x"], "UTC", _now())
    assert when == datetime(2026, 10, 23, 9, 0, tzinfo=UTC)
    when, rest = S.parse_when(["2026-11-02", "18:00", "hi"], "UTC", _now())
    assert when == datetime(2026, 11, 2, 18, 0, tzinfo=UTC) and rest == ["hi"]
    when, _ = S.parse_when(["20:00", "x"], "Asia/Tehran", _now())              # Tehran clock
    assert when == datetime(2026, 10, 22, 16, 30, tzinfo=UTC)
    for bad in (["5s", "x"], ["25:00"], ["سلام"], [], ["2026-13-40", "10:00"], ["2020-01-01", "10:00"], ["400d", "x"]):
        with pytest.raises(S.WhenError):
            S.parse_when(bad, "UTC", _now())


def test_options_pin_silent_poll():
    opts, text = S.parse_options(["pin", "silent", "سلام", "دنیا"])
    assert opts["pin"] and opts["silent"] and not opts["poll"] and text == "سلام دنیا"
    opts, text = S.parse_options(["poll", "multi", "pin", "رنگ؟", "|", "الف", "|", "ب"])
    assert opts["poll"] and opts["multi"] and opts["pin"] and text == "رنگ؟ | الف | ب"
    assert S.parse_options(["فقط", "متن"])[1] == "فقط متن"


# ================================================================== .sched module
class SchedClient(FakeClient):
    def __init__(self):
        super().__init__()
        self.sent_scheduled, self.pins, self.mine = [], [], []

    async def send_message(self, chat, text=None, **kw):
        self.sent_scheduled.append(("msg", chat, text, kw))
        return SimpleNamespace(id=1)

    async def send_file(self, chat, media, **kw):
        self.sent_scheduled.append(("file", chat, media, kw))
        return SimpleNamespace(id=2)

    async def pin_message(self, chat, mid):
        self.pins.append((chat, mid))

    def iter_messages(self, chat, **kw):
        msgs = list(self.mine)

        async def gen():
            for m in msgs:
                yield m
        return gen()


def _sched_env(monkeypatch):
    from modules import sched

    async def ok(client, chat, right, **kw):
        return SimpleNamespace(allowed=True, reason="")
    monkeypatch.setattr(sched, "require_group_right", ok)
    monkeypatch.setattr(sched, "TZ", "UTC")
    client = SchedClient()
    db = asyncio.run(make_db())
    sched.setup(client, db)
    return sched, client, db


def test_sched_text_with_reply_and_pin_job(monkeypatch):
    sched, client, db = _sched_env(monkeypatch)

    async def run():
        ev = FE(client, ".sched 10m pin سلام به همه", mid=90)
        ev.reply_to_msg_id = 55
        ev.message.reply_to = SimpleNamespace(reply_to_msg_id=55, forum_topic=False, reply_to_top_id=None)
        await dispatch(client, "sched_cmd", ev)
        kind, chat, text, kw = client.sent_scheduled[-1]
        assert kind == "msg" and text == "سلام به همه" and isinstance(kw["schedule"], datetime)
        assert 540 < (kw["schedule"] - datetime.now(UTC)).total_seconds() <= 600
        assert "پین" in ev.replies[-1]
        row = await db.fetchone("SELECT * FROM sched_pins")
        assert row["text"] == "سلام به همه" and row["kind"] == "text"
        # the message is sent by Telegram: when it exists, the pin job pins it
        await db.execute("UPDATE sched_pins SET due=?", (time.time() - 5,))
        client.mine = [SimpleNamespace(id=777, date=datetime.now(UTC), raw_text="سلام به همه", poll=None)]
        await client._hapoyi_sched_pin_due()
        assert client.pins == [(-1001, 777)] and await db.fetchone("SELECT 1 FROM sched_pins") is None
    asyncio.run(run())


def test_sched_poll_and_errors(monkeypatch):
    sched, client, db = _sched_env(monkeypatch)

    async def run():
        ev = FE(client, ".sched فردا 18:00 poll multi بهترین رنگ؟ | قرمز | آبی | سبز", mid=91)
        await dispatch(client, "sched_cmd", ev)
        kind, chat, media, kw = client.sent_scheduled[-1]
        assert kind == "file" and len(media.poll.answers) == 3 and media.poll.multiple_choice and kw["schedule"].hour in (14, 15, 18)
        for text, frag in ((".sched 10m poll فقط سؤال", "فرمت نظرسنجی"), (".sched 3s x", "حداقل"), (".sched سلام", "زمان"), (".sched 10m", "متن")):
            n = len(client.sent_scheduled)
            e = FE(client, text, mid=92)
            await dispatch(client, "sched_cmd", e)
            assert len(client.sent_scheduled) == n and frag in e.replies[-1], text
    asyncio.run(run())


def test_sched_pin_loop_function_pins_the_poll(monkeypatch):
    sched, client, db = _sched_env(monkeypatch)

    async def run():
        ev = FE(client, ".sched 10m pin poll سؤال؟ | الف | ب", mid=93)
        await dispatch(client, "sched_cmd", ev)
        await db.execute("UPDATE sched_pins SET due=?", (time.time() - 5,))
        client.mine = [SimpleNamespace(id=888, date=datetime.now(UTC), raw_text="", poll=object())]
        await client._hapoyi_sched_pin_due()
        assert client.pins == [(-1001, 888)]
    asyncio.run(run())


# ================================================================== modcheck
def test_swear_and_spam_rules_catch_disguises_and_leave_normal_talk():
    for t in ("تو یه کـــیــر خری", "fuuuuck you", "ک.ی.ر", "پدر سگ", "FUCK"):
        assert M.find_swear(t), t
    for t in ("سلام خوبی؟", "کیرشهر یه شهره", "bitcoin price today", "من شیرینی خریدم", "classic", "هواشناسی فردا"):
        assert M.find_swear(t) is None, t
    assert M.find_swear("این رو بگو", ("بگو",)) == "بگو"                         # the owner's own word
    assert M.static_spam("https://t.me/+AbCd") == "لینک دعوت"
    assert M.static_spam("http://a.com http://b.com") == "چند لینک"
    assert M.static_spam("کسب درآمد روزانه @mychannel") == "تبلیغ"
    assert M.static_spam("@aaaa @bbbb @cccc @dddd @eeee") == "منشن انبوه"
    assert M.static_spam("ببین این خبر رو https://news.example/a") is None
    assert M.static_spam("فروش ویژه") is None                                    # an advert word alone (no link / channel / number) is fine
    f = M.Flood()
    assert [f.check(1, 2, "یک پیام تکراری", t) for t in (0, 5, 10)] == [None, None, "تکرار یک پیام"]
    assert [f.check(1, 3, f"m{i}", 100 + i) for i in range(6)][-1] == "ارسال پشت‌سرهم"
    assert M.ai_verdict('{"v": "spam"}') == "spam" and M.ai_verdict("بله") == "ok" and M.ai_verdict('{"v":"hack"}') == "ok"


# ================================================================== .modai module
class MEvent:
    def __init__(self, text, sender=555, chat=-1001):
        self.raw_text, self.sender_id, self.chat_id, self.is_group, self.out = text, sender, chat, True, False
        self.deleted = False

    async def delete(self):
        self.deleted = True

    async def get_sender(self):
        return SimpleNamespace(id=self.sender_id, first_name="Bob", last_name=None, username=None)


def _modai_env(monkeypatch, admins=()):
    from modules import modai

    async def ok(client, chat, right, **kw):
        return SimpleNamespace(allowed=True, reason="")

    async def is_admin(client, chat, uid, **kw):
        return uid in admins
    rights = []

    async def ban(client, chat, uid, r):
        rights.append((uid, r))
    monkeypatch.setattr(modai, "require_group_right", ok)
    monkeypatch.setattr(modai, "target_is_admin", is_admin)
    monkeypatch.setattr(modai, "edit_banned", ban)
    client = FakeClient()
    notes = []

    async def send_message(chat, text, **kw):
        notes.append(text)
        return SimpleNamespace(id=4000)

    async def delete_messages(chat, ids):
        return None
    client.send_message, client.delete_messages = send_message, delete_messages
    client.get_me = lambda: None
    db = asyncio.run(make_db())
    modai.setup(client, db)
    return modai, client, db, rights, notes


def test_modai_commands_and_selective_deletion(monkeypatch):
    modai, client, db, rights, notes = _modai_env(monkeypatch, admins={7})
    monkeypatch.setattr(asyncio, "sleep", lambda *_a, **_k: _noop())

    async def run():
        _, watcher = _find(client, "watcher")
        async def cmd(text):
            e = FE(client, text, mid=90)
            await dispatch(client, "modai_cmd", e)
            return e.replies[-1]
        assert "خاموش" in await cmd(".modai status")
        r = await cmd(".modai spam on")
        assert "اسپم: روشن" in r and "فحاشی: خاموش" in r
        # "delete spam but swearing is fine"
        spam, swear, fine = MEvent("عضو شو @mychannel https://t.me/x"), MEvent("تو یه کیر خری"), MEvent("سلام")
        for e in (spam, swear, fine):
            await watcher(e)
        assert spam.deleted and not swear.deleted and not fine.deleted
        await cmd(".modai swear on")
        e2 = MEvent("تو یه کیر خری", sender=556)
        await watcher(e2)
        assert e2.deleted
        # admins and the whitelist are exempt; scope all removes the exemption
        adm = MEvent("کیر", sender=7)
        await watcher(adm)
        assert not adm.deleted
        await db.execute("INSERT INTO whitelist(chat_id,user_id) VALUES(-1001,9)")
        wl = MEvent("کیر", sender=9)
        await watcher(wl)
        assert not wl.deleted
        await cmd(".modai scope all")
        adm2 = MEvent("کیر", sender=7)
        await watcher(adm2)
        assert adm2.deleted
        # the log says who / why / what / what was done - nothing happens in the dark
        log = await cmd(".modai log")
        assert "Bob" in log and "تبلیغ" in log and "حذف" in log and "کیر" in log
        # own words
        await cmd(".modai words add قرمز")
        w = MEvent("قرمز", sender=558)
        await watcher(w)
        assert w.deleted
        assert "قرمز" in await cmd(".modai words list")
        await cmd(".modai off")
        off = MEvent("کیر", sender=559)
        await watcher(off)
        assert not off.deleted
    asyncio.run(run())


async def _noop():
    return None


def test_modai_escalation_mute_after_three(monkeypatch):
    modai, client, db, rights, notes = _modai_env(monkeypatch)
    monkeypatch.setattr(asyncio, "sleep", lambda *_a, **_k: _noop())

    async def run():
        _, watcher = _find(client, "watcher")
        for t in (".modai swear on", ".modai notice off", ".modai action mute 1h after 3"):
            await dispatch(client, "modai_cmd", FE(client, t, mid=90))
        evs = [MEvent("کیر", sender=600) for _ in range(3)]
        for i, e in enumerate(evs):
            await watcher(e)
            assert e.deleted
            assert len(rights) == (1 if i == 2 else 0)
        uid, r = rights[0]
        assert uid == 600 and r.send_messages and r.until_date is not None
        assert not notes
        st = FE(client, ".modai status", mid=91)
        await dispatch(client, "modai_cmd", st)
        assert "حذف + میوت 60 دقیقه" in st.replies[-1] and "بعد از 3 تخلف" in st.replies[-1]
        bad = FE(client, ".modai action mute abc", mid=92)
        await dispatch(client, "modai_cmd", bad)
        assert "❌" in bad.replies[-1]
    asyncio.run(run())


def test_modai_ai_judge_only_for_what_rules_miss(monkeypatch):
    modai, client, db, rights, notes = _modai_env(monkeypatch)
    monkeypatch.setattr(asyncio, "sleep", lambda *_a, **_k: _noop())
    script = Script('{"v": "spam"}', '{"v": "ok"}', '{"v": "swear"}')
    client._hapoyi_ask_ai = script

    async def run():
        _, watcher = _find(client, "watcher")
        for t in (".modai spam on", ".modai ai on", ".modai notice off"):
            await dispatch(client, "modai_cmd", FE(client, t, mid=90))
        a = MEvent("بیا کانال ما برای سود زیاد و رایگان")
        b = MEvent("امروز هوا خیلی خوبه برای پیاده روی")
        c = MEvent("خیلی بد گفتی مرتیکه احمق نادان")           # judged "swear" but swear is OFF -> stays
        for e in (a, b, c):
            await watcher(e)
        assert a.deleted and not b.deleted and not c.deleted and len(script.calls) == 3
        short = MEvent("سلام")
        await watcher(short)
        assert len(script.calls) == 3                          # too short for the AI judge
    asyncio.run(run())


# ================================================================== .gai
def test_gai_calling_words():
    from modules import gai

    W = gai.DEFAULT_WORDS
    assert gai.trigger_split("ربات این رو میوت کن", W) == "این رو میوت کن"
    assert gai.trigger_split("هاپویی، بن کن", W) == "بن کن"
    assert gai.trigger_split("Hapoyi mute him", W) == "mute him"
    assert gai.trigger_split("رباتیک چیه", W) is None and gai.trigger_split("سلام ربات", W) is None and gai.trigger_split("ربات", W) is None


def _gai_env(perms, *answers):
    from modules import gai

    GB, ctrl, client, db, fed = _gb_env(perms)
    client._hapoyi_groupbot = ctrl
    script = Script(*answers)
    client._hapoyi_ask_ai = script

    async def get_messages(chat, limit=None, ids=None, **kw):
        return SimpleNamespace(id=ids, sender_id=555) if ids else []
    client.get_messages = get_messages
    gai.setup(client, db)
    return gai, GB, ctrl, client, db, fed, script


def _gai_msg(text, sender, replied=None):
    e = GEvent(text, sender, replied)
    e.out = False
    e.id = 700
    e.get_sender = lambda: _async(SimpleNamespace(first_name="Ali"))
    return e


async def _async(v):
    return v


async def _settle(client):
    """`.gai` works in the background (1.19.5: nothing waits for the AI): wait for the jobs it started."""
    tasks = list(client._hapoyi_gai_state["tasks"])
    if tasks:
        await asyncio.gather(*tasks, return_exceptions=True)


def test_gai_admin_asks_in_words_and_commands_run_within_his_rights(monkeypatch):
    perms = {7: _adm(), 8: _adm(ban=False)}
    plan = json.dumps({"reply": "فلانی میوت شد", "actions": [{"cmd": ".mute 1d", "on_reply": True}], "clarify": ""}, ensure_ascii=False)
    gai, GB, ctrl, client, db, fed, script = _gai_env(perms, plan, json.dumps({"reply": "", "actions": [{"cmd": ".ban", "on_reply": True}]}),
                                                        json.dumps({"reply": "", "actions": [{"cmd": ".friend add"}, {"cmd": ".dl x"}, {"cmd": ".do بکن"}]}))

    async def run():
        await ctrl.ensure()
        await db.execute("INSERT INTO gb_chats(chat_id,enabled) VALUES(-1001,1)")
        await db.execute("CREATE TABLE IF NOT EXISTS gai_chats (chat_id INTEGER PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 1, words TEXT NOT NULL DEFAULT '[]')")
        await db.execute("INSERT INTO gai_chats(chat_id,enabled) VALUES(-1001,1)")
        _, talk = _find(client, "talk")
        r = SimpleNamespace(id=42, sender_id=555)
        await talk(_gai_msg("ربات این رو تا فردا میوت کن", 7, r))
        await _settle(client)
        assert fed == [(".mute 1d", 42)]
        assert "AI" not in script.calls[0][0]["content"][:5] and ".friend" not in script.calls[0][0]["content"] and ".mute" in script.calls[0][0]["content"]
        # a person who is not an admin / delegate gets nothing (no AI call at all)
        n = len(script.calls)
        await talk(_gai_msg("ربات منو ادمین کن", 66, r))
        await _settle(client)
        assert len(script.calls) == n
        # an admin WITHOUT the Ban right: the AI plans `.ban`, the real rights stop it
        e8 = _gai_msg("ربات بنش کن", 8, r)
        await talk(e8)
        await _settle(client)
        assert len(fed) == 1 and any("شدنی نیست" in x for x in e8.replied)
        # the owner's private features are not reachable: every one of them is refused, nothing is sent
        n = len(fed)
        st = client._hapoyi_gai_state
        st["gap"].clear()
        await talk(_gai_msg("ربات یه چیز دیگه", 7, r))
        await _settle(client)
        assert len(fed) == n
        for t in list(ctrl.tasks):
            t.cancel()
    asyncio.run(run())


def test_gai_group_prompt_has_only_group_commands_and_history_ids():
    msgs = A.build_group_messages("روی پیام ساعت 17:03 نظرسنجی بساز", prefix=".", reply_info=None, asker="Ali",
                                  history=[{"id": 12, "t": "17:03", "who": "Reza", "text": "سلام"}], now_text="2026-10-22 19:00")
    system = msgs[0]["content"]
    assert ".mute" in system and ".sched" in system and ".modai" in system and ".poll" in system
    for private in (".friend", ".autoreply", ".dl ", ".do ", ".echo"):
        assert private not in system, private
    assert "12 | 17:03 | Reza | سلام" in system
    p = A.parse_plan(json.dumps({"actions": [{"cmd": ".mute 1h"}, {"cmd": ".friend add"}, {"cmd": ".autoreply add a => b"}, {"cmd": ".poll س | الف | ب"}]}), ".",
                     set(A.GROUP_COMMANDS))
    assert [a.name for a in p.actions] == ["mute", "poll"] and len(p.rejected) == 2


def test_groupbot_rights_for_new_commands():
    GB = _gb_env({})[0]
    ok = lambda cmd, **kw: GB.allowed(cmd, **{"is_admin": True, "rights": set(), "is_creator": False, "level": None, **kw})  # noqa: E731
    assert ok("poll") and ok("sched") and not ok("modai") and ok("modai", rights={"delete_messages"})
    assert ok("modai", is_admin=False, level="full") and not ok("modai", is_admin=False, level="mod")


# ================================================================== docs for `.do` and `.ask`
def test_do_knows_the_new_commands_and_routes_requests_to_their_docs():
    known = K.known_commands()
    assert {"modai", "sched", "gai", "gbot", "delegate", "poll", "captcha"} <= known
    for q, key in (("در این گروه اسپم رو حذف کن ولی فحاشی مهم نیست", "modai"), ("فردا ساعت 9 یه نظرسنجی بذار و پینش کن", "sched"), ("ادمین ها به ai دسترسی داشته باشن", "groupai")):
        assert key in [k for k, _ in K.score_sections(q)][:4], q
    manual = A.manual_for("اسپم رو حذف کن ولی فحاشی نه")
    assert ".modai spam on|off" in manual
    assert "{p}modai spam on" in A.SYNTAX_NOTES and "{p}sched" in A.SYNTAX_NOTES
    p = A.parse_plan(json.dumps({"actions": [{"cmd": ".modai spam on"}, {"cmd": ".modai swear off"}, {"cmd": ".sched 17:30 pin سلام"}, {"cmd": ".gai on"}]}), ".", known)
    assert [a.name for a in p.actions] == ["modai", "modai", "sched", "gai"] and not p.rejected


# ================================================================== a file that cannot be replaced (Docker bind mount): `.aiknow add` EBUSY
def test_writes_survive_a_busy_target_file(tmp_path, monkeypatch):
    import errno
    import os

    from services import knowledge as KN
    from utils.atomic import write_text_atomic

    target = tmp_path / "ai_knowledge.json"
    target.write_text("{}")
    real_replace = os.replace

    def busy(src, dst, *a, **k):
        if str(dst) == str(target):
            raise OSError(errno.EBUSY, "Device or resource busy")
        return real_replace(src, dst, *a, **k)
    monkeypatch.setattr(os, "replace", busy)
    write_text_atomic(target, "سلام")
    assert target.read_text("utf-8") == "سلام" and [p.name for p in tmp_path.iterdir()] == ["ai_knowledge.json"]   # no .tmp left behind
    store = KN.KnowledgeStore(target)
    if store is not None:
        target.write_text("{}")
        rid, why = store.add("قیمت اشتراک ۱۰۰ تومان", "قیمت")
        assert rid and not why and store.items()[0]["text"].startswith("قیمت")
