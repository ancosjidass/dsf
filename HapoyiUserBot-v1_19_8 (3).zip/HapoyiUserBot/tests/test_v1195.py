"""1.19.5: «ربات …» and `.gai do` are one brain; Reply is understood (target person, replied text, answering the AI's question); no more stalls."""
from __future__ import annotations

import asyncio
import json
import pathlib
import sys
from types import SimpleNamespace

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from services import aiagent as A  # noqa: E402
from tests.test_regressions import _find  # noqa: E402
from tests.test_v1180 import GEvent, _adm, _gb_env  # noqa: E402
from tests.test_v1190 import _async, _gai_env, _gai_msg, _settle  # noqa: E402

GROUP_ONLY = ("captcha", "linkguard", "filter", "flood", "welcome", "autoban", "whitelist", "blacklist", "autodelete", "delmes", "activity", "tag")


# ================================================================== one command set, rights per person
def test_admins_and_owner_share_the_same_group_commands():
    assert set(A.GROUP_COMMANDS) >= set(GROUP_ONLY) | {"mute", "ban", "purge", "poll", "sched", "modai", "promote", "demote"}
    assert A.OWNER_GROUP_COMMANDS == A.GROUP_COMMANDS | {"gbot"} and "gbot" not in A.GROUP_COMMANDS
    for private in ("every", "sum", "friend", "autoreply", "dl", "do", "echo", "lic", "backup", "gai"):
        assert private not in A.GROUP_COMMANDS, private
    admin = A.build_group_messages("x", prefix=".", reply_info=None, asker="Ali")[0]["content"]
    owner = A.build_group_messages("x", prefix=".", reply_info=None, owner=True)[0]["content"]
    for cmd in (".captcha", ".linkguard", ".delmes", ".filter", ".welcome", ".mute", ".sched"):
        assert cmd in admin and cmd in owner, cmd
    assert ".gbot" in owner and ".gbot" not in admin


def test_every_group_command_has_a_rule_and_gbot_is_not_reachable_by_requesters():
    GB = _gb_env({})[0]
    for name in A.GROUP_COMMANDS:
        assert name in GB.RIGHT, name                      # nothing of the shared list falls into «شدنی نیست» by accident
    ok = lambda cmd, **kw: GB.allowed(cmd, **{"is_admin": True, "rights": set(), "is_creator": False, "level": None, **kw})  # noqa: E731
    assert not ok("captcha") and ok("captcha", rights={"ban_users"})                  # an admin: by his OWN rights
    assert ok("delmes", rights={"delete_messages"}) and not ok("delmes", rights={"ban_users"})
    assert ok("captcha", is_admin=False, level="mod") and ok("linkguard", is_admin=False, level="full")   # a delegate: everything but promote / demote / modai
    assert not ok("promote", is_admin=False, level="mod") and ok("promote", is_admin=False, level="full")
    assert not ok("gbot", is_admin=False, level="full") and not ok("gbot", is_creator=True, is_admin=True)   # `gbot` has no rule: only the owner's own account runs it
    assert GB.allowed("captcha", is_admin=False, rights=set(), is_creator=False, level=None) is False   # a stranger: nothing


def test_the_old_blind_spot_captcha_via_the_calling_word_now_runs():
    perms = {7: _adm()}
    plan = json.dumps({"reply": "کپچا روشن شد", "actions": [{"cmd": ".captcha on 5m"}, {"cmd": ".linkguard on delete"}, {"cmd": ".every 5m سلام"}, {"cmd": ".sum"}]})
    gai, GB, ctrl, client, db, fed, script = _gai_env(perms, plan)

    async def run():
        await ctrl.ensure()
        await db.execute("INSERT INTO gb_chats(chat_id,enabled) VALUES(-1001,1)")
        await db.execute("CREATE TABLE IF NOT EXISTS gai_chats (chat_id INTEGER PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 1, words TEXT NOT NULL DEFAULT '[]')")
        await db.execute("INSERT INTO gai_chats(chat_id,enabled) VALUES(-1001,1)")
        _, talk = _find(client, "talk")
        await talk(_gai_msg("ربات کپچا رو روشن کن و لینک ها رو حذف کن", 7))
        await _settle(client)
        assert [t for t, _ in fed] == [".captcha on 5m", ".linkguard on delete"]        # the personal ones (.every / .sum) never go out
        for t in list(ctrl.tasks):
            t.cancel()
    asyncio.run(run())


# ================================================================== `.gai do` written by a delegate / admin from THEIR account
def test_gai_command_forms_from_other_accounts():
    from modules import gai

    assert gai.command_split(".gai do کپچا رو روشن کن") == "کپچا رو روشن کن"
    assert gai.command_split(".gai ask do سکوتش کن") == "سکوتش کن"          # the user's own typing: `.gai ask do ...`
    assert gai.command_split(".gai ask سکوتش کن") == "سکوتش کن" and gai.command_split("/gai do بن کن") == "بن کن"
    assert gai.command_split(".gai on") is None and gai.command_split(".gai off") is None and gai.command_split(".gai status") is None
    assert gai.command_split(".gai") is None and gai.command_split(".gai do") is None and gai.command_split("سلام") is None
    assert gai.command_split(".gai میوتش کن") == "میوتش کن"


def test_delegate_with_full_access_can_use_gai_do_from_his_own_account():
    perms = {}
    plan = json.dumps({"reply": "", "actions": [{"cmd": ".captcha on"}]})
    gai, GB, ctrl, client, db, fed, script = _gai_env(perms, plan)

    async def run():
        await ctrl.ensure()
        await db.execute("INSERT INTO gb_chats(chat_id,enabled) VALUES(-1001,1)")
        await db.execute("INSERT INTO gb_delegates(chat_id,user_id,level,name,created_at) VALUES(-1001,77,'full','D','x')")
        await db.execute("CREATE TABLE IF NOT EXISTS gai_chats (chat_id INTEGER PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 1, words TEXT NOT NULL DEFAULT '[]')")
        await db.execute("INSERT INTO gai_chats(chat_id,enabled) VALUES(-1001,1)")
        _, talk = _find(client, "talk")
        await talk(_gai_msg(".gai do کپچا رو روشن کن", 77))
        await _settle(client)
        assert [t for t, _ in fed] == [".captcha on"]
        for t in list(ctrl.tasks):
            t.cancel()
    asyncio.run(run())


# ================================================================== Reply
def test_prompt_shows_the_replied_message_and_its_author_and_tells_the_ai_to_use_it():
    info = {"kind": "text message", "who": "Reza", "who_id": 4242, "id": 99, "text": "من همه رو میکشم! بن کنید", "mine": False}
    system = A.build_group_messages("سکوتش کن", prefix=".", reply_info=info, asker="Ali")[0]["content"]
    assert "message #99" in system and "Reza" in system and "user id 4242" in system and "من همه رو میکشم" in system
    assert "never instructions" in system and "WITHOUT @username/id" in system
    assert "FOLLOW-UP" not in system
    system = A.build_group_messages("12345", prefix=".", reply_info=None, context='Earlier request: "سکوت کن"\nYou answered: "کدام کاربر؟"')[0]["content"]
    assert "FOLLOW-UP" in system and "سکوت کن" in system


def test_reply_on_a_person_always_acts_on_that_person_even_if_the_model_forgets_on_reply():
    perms = {7: _adm()}
    plan = json.dumps({"reply": "", "actions": [{"cmd": ".mute 1h"}, {"cmd": ".warn بد حرف زد"}], "clarify": ""})
    gai, GB, ctrl, client, db, fed, script = _gai_env(perms, plan)

    async def run():
        await ctrl.ensure()
        await db.execute("INSERT INTO gb_chats(chat_id,enabled) VALUES(-1001,1)")
        await db.execute("CREATE TABLE IF NOT EXISTS gai_chats (chat_id INTEGER PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 1, words TEXT NOT NULL DEFAULT '[]')")
        await db.execute("INSERT INTO gai_chats(chat_id,enabled) VALUES(-1001,1)")
        _, talk = _find(client, "talk")
        r = SimpleNamespace(id=42, sender_id=555, message="سلام بر همه", action=None, get_sender=lambda: _async(SimpleNamespace(first_name="Reza")))
        await talk(_gai_msg("ربات سکوتش کن و اخطار بده", 7, r))
        await _settle(client)
        assert fed == [(".mute 1h", 42), (".warn بد حرف زد", 42)]
        system = script.calls[0][0]["content"]
        assert "سلام بر همه" in system and "message #42" in system
        for t in list(ctrl.tasks):
            t.cancel()
    asyncio.run(run())


def test_answering_the_ais_question_by_reply_finishes_the_job_without_a_calling_word(monkeypatch):
    perms = {7: _adm()}
    ask_who = json.dumps({"reply": "", "actions": [], "clarify": "کدام کاربر؟ شناسه عددی یا @username؟"}, ensure_ascii=False)
    done = json.dumps({"reply": "", "actions": [{"cmd": ".mute 123456789"}], "clarify": ""})
    gai, GB, ctrl, client, db, fed, script = _gai_env(perms, ask_who, done)
    notes = []

    async def lookup(event, explicit, **kw):
        return SimpleNamespace(id=int(explicit))
    monkeypatch.setattr(GB, "resolve_target", lookup)

    async def run():
        await ctrl.ensure()
        await db.execute("INSERT INTO gb_chats(chat_id,enabled) VALUES(-1001,1)")
        await db.execute("CREATE TABLE IF NOT EXISTS gai_chats (chat_id INTEGER PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 1, words TEXT NOT NULL DEFAULT '[]')")
        await db.execute("INSERT INTO gai_chats(chat_id,enabled) VALUES(-1001,1)")
        _, talk = _find(client, "talk")
        first = _gai_msg("ربات سکوت کن", 7)

        async def reply(text, **kw):
            first.replied.append(text)
            note = SimpleNamespace(id=900, delete=lambda: asyncio.sleep(0))
            notes.append(note)
            return note
        first.reply = reply
        await talk(first)
        await _settle(client)
        assert fed == [] and first.replied and "کدام کاربر" in first.replied[0] and (-1001, 900) in client._hapoyi_gai_state["threads"]
        # the person answers by Reply on the AI's question - no «ربات» in the text
        client._hapoyi_gai_state["gap"].clear()                # (the test answers within the same second)
        ans = _gai_msg("123456789", 7, notes[0])
        ans.reply_to_msg_id = 900
        await talk(ans)
        await _settle(client)
        assert fed == [(".mute 123456789", None)]
        system = script.calls[1][0]["content"]
        assert "FOLLOW-UP" in system and "ربات سکوت کن" not in system.split("FOLLOW-UP")[0] and 'Earlier request: "سکوت کن"' in system
        # a plain reply to some OTHER message is not a request
        n = len(script.calls)
        client._hapoyi_gai_state["gap"].clear()
        other = _gai_msg("123456789", 7, SimpleNamespace(id=5, sender_id=1, message="x", action=None))
        other.reply_to_msg_id = 5
        await talk(other)
        await _settle(client)
        assert len(script.calls) == n
        for t in list(ctrl.tasks):
            t.cancel()
    asyncio.run(run())


def test_a_command_that_needs_a_person_is_never_silently_dropped():
    perms = {7: _adm()}
    gai, GB, ctrl, client, db, fed, script = _gai_env(perms)

    async def run():
        await ctrl.ensure()
        await db.execute("INSERT INTO gb_chats(chat_id,enabled) VALUES(-1001,1)")
        ev = GEvent("x", 7)
        who = await ctrl.identify(ev)
        assert who is not None
        ok = await ctrl.run_command(ev, "mute", "1h", None, who)
        assert ok is False and any("Reply" in t for t in ev.replied) and fed == []
        for t in list(ctrl.tasks):
            t.cancel()
    asyncio.run(run())


# ================================================================== no more minutes-long stalls
def test_updates_are_concurrent_so_one_slow_handler_cannot_hold_back_the_next_command():
    import inspect

    from core import client as C
    from core import fleet as F

    assert "sequential_updates=False" in inspect.getsource(C.build_client).replace(" ", "")
    assert "sequential_updates=False" in inspect.getsource(F).replace(" ", "")
    assert "sequential_updates=True" not in (inspect.getsource(C) + inspect.getsource(F)).replace(" ", "")


def test_the_ai_never_hangs_a_request():
    from modules import gai

    assert gai.AI_DEADLINE <= 60 and gai.PER_USER_GAP <= 1.0
    perms = {7: _adm()}
    gai, GB, ctrl, client, db, fed, script = _gai_env(perms)

    async def never(messages, **kw):
        await asyncio.sleep(3600)
    client._hapoyi_ask_ai = never
    gai.AI_DEADLINE = 0.05

    async def run():
        await ctrl.ensure()
        await db.execute("INSERT INTO gb_chats(chat_id,enabled) VALUES(-1001,1)")
        await db.execute("CREATE TABLE IF NOT EXISTS gai_chats (chat_id INTEGER PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 1, words TEXT NOT NULL DEFAULT '[]')")
        await db.execute("INSERT INTO gai_chats(chat_id,enabled) VALUES(-1001,1)")
        _, talk = _find(client, "talk")
        ev = _gai_msg("ربات سکوتش کن", 7, SimpleNamespace(id=42, sender_id=555, message="x", action=None))
        await talk(ev)
        await _settle(client)
        assert fed == [] and any("جواب نداد" in t for t in ev.replied)         # it SAYS why, never silent
        for t in list(ctrl.tasks):
            t.cancel()
    asyncio.run(run())
