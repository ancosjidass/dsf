"""Panels (inline `.menu`, `.models`, `.mail` ...) belong to the account that opened them (1.19.7).

Bug before: two people who both run the self meet in a group; A opens `.menu`; B (who also has the self) presses A's buttons and the bot treated B as «an owner»
(and edited A's message with B's data). Now every callback button of such a panel carries the id of the opener (`ui:dash~2xk9a`) and a click of anybody else is
refused. Telegram gives a callback only 64 bytes: the tag is short (base 36) and a button whose data would not fit is left untagged (then the old rule applies).
"""
from __future__ import annotations

from typing import Any

SEP = "~"
MAX_DATA = 64


def to_tag(user_id: int) -> str:
    n, out = abs(int(user_id)), ""
    while n:
        n, r = divmod(n, 36)
        out = "0123456789abcdefghijklmnopqrstuvwxyz"[r] + out
    return out or "0"


def from_tag(tag: str) -> int | None:
    try:
        return int(tag, 36)
    except (TypeError, ValueError):
        return None


def tag_bytes(data: bytes, owner_id: int) -> bytes:
    """`ui:x` -> `ui:x~tag` (not twice, not when it would not fit into 64 bytes)."""
    if not isinstance(data, (bytes, bytearray)) or SEP.encode() in data:
        return bytes(data) if isinstance(data, (bytes, bytearray)) else data
    new = bytes(data) + SEP.encode() + to_tag(owner_id).encode()
    return new if len(new) <= MAX_DATA else bytes(data)


def split_data(data: str) -> tuple[str, int | None]:
    """`ui:x~tag` -> (`ui:x`, owner id).  Untagged -> (data, None)."""
    if SEP in data:
        clean, _, tag = data.rpartition(SEP)
        owner = from_tag(tag)
        if owner is not None:
            return clean, owner
    return data, None


def _tag_one(button: Any, owner_id: int, prefixes: tuple[str, ...]) -> None:
    for holder in (getattr(button, "button", None), getattr(button, "type", None), button):     # old Telethon: Button.button, new layer: .type, raw TL: itself
        data = getattr(holder, "data", None) if holder is not None else None
        if isinstance(data, (bytes, bytearray)):
            if data.startswith(tuple(p.encode() for p in prefixes)):
                try:
                    holder.data = tag_bytes(data, owner_id)
                except Exception:  # noqa: BLE001
                    continue
            return


def tag_buttons(buttons: Any, owner_id: int, prefixes: tuple[str, ...] = ("ui:",)) -> Any:
    """Mark every callback button (data starting with one of `prefixes`) of a button layout with the owner. Works in place and returns the layout."""
    if buttons is None or not owner_id:
        return buttons
    if isinstance(buttons, (list, tuple)):
        for item in buttons:
            tag_buttons(item, owner_id, prefixes)
    else:
        _tag_one(buttons, owner_id, prefixes)
    return buttons


def guard_event(event: Any, owner_id: int, prefixes: tuple[str, ...] = ("ui:",)) -> None:
    """After the click was accepted: whatever the handler `edit`s keeps the tag, so the panel stays the opener's."""
    original = event.edit

    async def edit(*args, **kwargs):
        if kwargs.get("buttons") is not None:
            tag_buttons(kwargs["buttons"], owner_id, prefixes)
        elif len(args) >= 3 and args[2] is not None:
            tag_buttons(args[2], owner_id, prefixes)
        return await original(*args, **kwargs)

    event.edit = edit
