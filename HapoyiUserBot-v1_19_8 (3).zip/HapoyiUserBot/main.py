from __future__ import annotations

import asyncio
import signal

from core.bootstrap import start


async def _runner() -> None:
    task = asyncio.current_task()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):  # systemd stop / Ctrl-C: shut down cleanly (writes OFFLINE for `.report`)
        try:
            loop.add_signal_handler(sig, task.cancel)
        except (NotImplementedError, RuntimeError):
            pass
    await start()


if __name__ == "__main__":
    try:
        asyncio.run(_runner())
    except (KeyboardInterrupt, asyncio.CancelledError):
        pass
