# 1.17.2 — `.do` runs every command

ROOT CAUSE #2 (found with a harness that loads all 52 real modules): the first fix handed ONE shared event to every matching handler.
`alias_runner` (shortcuts.py) matches EVERY command, so its regex overwrote `event.pattern_match` -> `.ban 123456789` lost its `target`
group («ID نامعتبر»), other commands saw wrong groups («فرمت اشتباه»). Now every handler gets its own event, the chat / sender /
replied message are attached up front (`.gif` / `.sticker` see the photo at once).

ROOT CAUSE #1 (found in Telethon 1.45 source): messages that THIS session sends with send_message() are never dispatched to
NewMessage handlers (their updates are flagged `_self_outgoing`). So a command sent by `.do` was only text; no handler ever ran it,
while the same text typed by hand worked. Fix: `.do` now hands every sent command to the command handlers itself
(modules/ai_agent.py `feed_handlers`); tested with real Telethon Event objects.

Other problems: `.do` showed the right command (e.g. `.ban`, `.mute`, `.blacklist`) but did not run it — the "sensitive" list
(CONFIRM) made the AI wait for a «بله» that never reached it, other commands were refused (BLOCKED / «دستور ناشناخته»).

Changes
- The ONE-TIME permission question stays: until the owner answers «بله» (or `.ai control on`) nothing runs; if it is not answered, every next `.do` asks again.
- Sensitive commands run at once. `.ai control danger on` brings the «بله» question back (opt-in).
- BLOCKED list is only `.do/.act/.agent` (a `.do` inside `.do` would loop forever). `.lic .backup .restore .macro .alias .protect .apikey .ai control ...` all work.
- A command is "known" when it is in the docs OR has a real handler in the running bot (`blacklist`, `roll`, `slots`, `muted`, ... no longer «ناشناخته»).
- Commands that act on a person/message (ban, mute, warn, promote ...) are always sent as a Reply to the replied message, whatever `on_reply` the model said.
- The model gets a bigger manual (11k chars) + the names of undocumented commands; limits raised: 12 actions per request, 30 requests per minute.

## Numeric id / "invalid username or id" (same release)
- `resolve_target` cleans what it gets: Persian digits, `@123456789`, `tg://user?id=`, `t.me/name`, hidden direction marks, quotes/backticks, trailing `.`/`،`.
- A numeric id Telegram does not know yet is looked up in the member lists of the chat (all, banned, muted, admins) - this also makes `.unban <id>` of a banned user work.
- `ban/mute/kick/unban...` (core/actions.edit_banned) use the same fallback and say clearly "not found in this group" instead of crashing.
- Store-only commands (`.whitelist`, `.blacklist add`, `.echo add`, `.relation`, `.autoreact`, `.repeat`, autodelete) keep the id even when Telegram cannot resolve it.
- `.do` cleans the model's command text before sending (id-like words after ban/mute/blacklist ... only; message texts are never touched).

## `.imagine` / `.img` / `.draw`: complete pictures only (same release)
- Cause of half / empty pictures: the download used `resp.content.read(n)`, which returns only the first chunk that has arrived, so a cut-off image was sent. Now the whole body is read.
- Every picture is fully decoded and checked before sending: cut-off, blank (flat colour) or tiny pictures are rejected and the next attempt/backend is used (free service: up to 3 tries with a new seed / model).
- webp/gif results become a normal photo; pictures over 9 MB are shrunk; sent with `force_document=False`.

## `.ss` screenshots: mixed Persian / Arabic / English / digits (same release)
- Without libraqm (typical VPS) Pillow could still pick its RAQM engine on a font and reorder text that was ALREADY shaped + reordered by us (letters / words in wrong places). The BASIC layout engine is now forced whenever our own shaping is used.
- Direction is decided per PARAGRAPH by its first strong character (like Telegram) and every wrapped line keeps it, in both engines: `Hello سلام ... test است 123` no longer flips digits / words, continuation lines holding only Latin / digits stay on the correct side.
- Persian digits are no longer treated as "RTL letters": a name like `Ali ۸:۳۶` (profile clock) stays `Ali ۸:۳۶` instead of becoming `۸:۳۶ Ali`; an RTL name keeps `۸:۳۶` as one number.
