# 1.19.1
- **`.aiknow add` → `OSError: [Errno 16] Device or resource busy`**: ذخیره با «فایل موقت + rename» بود و روی فایلی که Docker/bind-mount شده (یا فایل‌سیستم شبکه‌ای) rename ممنوع است. حالا `utils/atomic.write_text_atomic`: اول rename، اگر رد شد مستقیم داخل خود فایل می‌نویسد (فایل `.tmp` هم باقی نمی‌ماند). همین روش برای کلیدهای AI (`.apikey`) و وضعیت مصرف AI هم استفاده شد.
