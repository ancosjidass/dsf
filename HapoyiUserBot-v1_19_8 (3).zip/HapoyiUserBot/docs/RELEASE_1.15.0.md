# 1.15.0 "Dana"

## 1. AI that knows the self itself (`.guide`, `.ask`, `.aiknow`)

A new customer can ask the bot how to use the bot, in their own words and language.

* `.guide چجوری یه پیام رو زمان‌بندی کنم؟` → the AI understands the *meaning* (not only the keyword) and answers with the real command (`.later`, `.every`, `.remind`) and an example.
  Works the same for "schedule a message", "تایم مسیج", "send later", Turkish, Arabic, Russian ...
* `.ask` does the same automatically **when the question is about the bot**; every other question is answered normally (no manual is pasted into unrelated questions).
* It always answers on the account the self is running on, with that account's own daily AI quota (`AI_DAILY_PER_ACCOUNT`, main account `AI_DAILY_OWNER`).
* The docs of the bot are read from `modules/help.py` — always current, nothing to maintain. A new command you add to `help.py` is known to the AI immediately.
* **Owner notes** (`.aiknow`, main account only; every customer account reads them): prices, how to buy, renewal, support contact, rules, FAQ ...
  `.aiknow add قیمت | ماهانه ۱۵۰ هزار تومان` · `.aiknow list|show <id>|del <id>` · `.aiknow import` (Reply on a .txt/.md file, `import replace` wipes first) · `.aiknow clear confirm`.
  See `docs/AI_KNOWLEDGE_EXAMPLE.md` for a ready template. Stored in `data/ai_knowledge.json` (limits: 4000 chars per note, 80 000 total).

How a question is answered (to stay inside free quotas): local scoring picks likely sections → if it is not sure, one tiny AI "router" call picks the sections by meaning → the answer call gets only those sections + the owner's notes (never the whole manual).

## 2. Smart helper (`.aiguide on|off`)

* **ON**: when *you* (the self's user) look confused (`چرا کار نمیکنه؟؟`, "how do I…"), mistype a command (`.laterr`), get a bot error (`❌ …`) or laugh (`ههههه`, 😂, lol), a cheap local filter notices and the AI **decides from the situation** whether to say something. Silence is the default: it stays quiet in serious/sad/angry/political/money talk and when it has nothing useful.
* **OFF**: nothing happens by itself; only `.ask` / `.guide` answer (with the same docs + owner notes).
* Options: `fun on|off` (light-hearted lines too) · `where chat|saved` · `ttl <sec>` (help bubbles delete themselves, default 25 s, 0 = keep) · `here on|off` (per chat) · `ctx on|off` · `.aiguide status`.
* Everything it says starts with 🤖, it only watches *your own* messages, never answers other people, never answers *as you*.
* Cost control: at most one AI call per chat per `AIGUIDE_COOLDOWN` seconds (×3 for fun) and `AIGUIDE_DAILY` per day, on top of the account's normal AI quota.
* **Privacy**: to decide, the last ≤5 messages of that chat are sent to the AI provider, with anonymous labels (owner / A / B — no names). Use `ctx off` to send only your own message, `here off` to exclude a chat. The status text tells the user this.

## 3. Downloader (`.dl`)

YouTube, Instagram and TikTok through **yt-dlp** (server downloads, Telegram gets the file):

```
.dl <link>                 video 720p into the current chat   (or Reply on the message that has the link)
.dl 360|480|720|1080|4k <link>   .dl best <link>
.dl audio <link>           MP3          .dl me <link>   → Saved Messages        .dl info <link>   → title/duration/size only
.yt / .ig / .tt <link>     same command          دانلود <لینک>   (Persian)       .dl status
```

* Only YouTube/Instagram/TikTok hosts are accepted (exact host or sub-domain match); anything else — `localhost`, internal IPs, look-alike domains, `file://` — never reaches yt-dlp.
* Limits (`.env`): `DL_MAX_MB` 300, `DL_MAX_MINUTES` 60, `DL_DAILY_PER_ACCOUNT` 25 / `DL_DAILY_OWNER` 200, `DL_CONCURRENCY` 2; one download per account at a time; live streams refused.
* Needs `ffmpeg` (already in the installer) for merging video+audio and MP3.
* **Cookies**: private/limited Instagram posts and YouTube's "confirm you're not a bot" need a logged-in `cookies.txt` (`YTDLP_COOKIES=/path`); datacenter IPs hit that YouTube check often. Keep that file private. `YTDLP_PROXY` for geo-blocked videos.
* YouTube/Instagram change often: keep yt-dlp fresh with `pip install -U yt-dlp` (and restart). `.dl status` shows the installed version.
* `Reply + «دانلود»` on a message that contains such a link now starts `.dl` (before, it saved only the link-preview picture).

## Other

* Fix: five `.help` sections (power, echo, ai, groupguard, shortcuts) showed a literal `\n`; `docs/HELP.txt` regenerated.
* Menu: new **⬇️ دانلودر** section; AI section lists the new commands. Persian words: `.آموزش` = `.guide`, `.دانلودر` = `.dl`.
* Tests: `tests/test_v1150.py` (28 tests: routing in several languages, owner notes, helper decisions, URL allow-list, downloader flow with a fake yt-dlp).

## Upgrade

```bash
pip install -r requirements.txt     # adds yt-dlp
# .env: add the new keys from .env.example (all optional)
```
