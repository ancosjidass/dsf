"""Hāpoyi sandbox server - runs on YOUR OWN server (best inside the Docker container of this folder).

The self-bot (`.sb`) talks to it over HTTP with a secret token. Every request works inside a workspace folder
(/workspace/<session>/); the AI can run shell commands, write / edit / read files, upload a zip (or any file / gif / image) and
download a file or the whole workspace as a zip.

    SANDBOX_TOKEN        (required) long random secret - the same value goes into the .env of the self-bot
    SANDBOX_ROOT         /workspace
    SANDBOX_HOST/PORT    0.0.0.0 / 8765
    SANDBOX_MAX_UPLOAD   209715200  (200 MB)
    SANDBOX_MAX_TIMEOUT  900        (the longest a single command may run, seconds)
    SANDBOX_MAX_OUTPUT   20000      (characters of stdout / stderr that are returned)

The shell commands are arbitrary by design: the ISOLATION is the container (CPU / RAM limits, no secrets inside) - see docker-compose.yml. Never run this server on the same
machine / user as the bot's session files without the container.

1.19.7 - EVERY account may use it, so the accounts are isolated from each other INSIDE the container: when the server runs as root (the default of the Dockerfile) every session gets its own
unix user (uid 20000+, saved in .state/uids.json), its folder is mode 0700, its commands run as that user (limited processes / file size), and all file operations of the API
run as that user too (fsuid) - one account can neither read nor delete another account's files, nor read the environment (the token) of this server. `SANDBOX_ISOLATE=0` switches it off.
Also here: verified domains + SSL (domains.py, `/domains*`, `/tls/ask`) and temporary mail (tempmail.py, `/mail/*`, SMTP receiver).
"""
from __future__ import annotations

import asyncio
import contextlib
import ctypes
import hmac
import io
import json
import os
import random
import re
import secrets
import shutil
import signal
import threading
import time
import zipfile
from pathlib import Path

import aiohttp
from aiohttp import web

import domains as dom
import guardrules
import tempmail
import webread

TOKEN = os.getenv("SANDBOX_TOKEN", "")
ROOT = Path(os.getenv("SANDBOX_ROOT", "/workspace")).resolve()
MAX_UPLOAD = int(os.getenv("SANDBOX_MAX_UPLOAD", str(200 * 1024 * 1024)))
MAX_TIMEOUT = int(os.getenv("SANDBOX_MAX_TIMEOUT", "900"))
MAX_OUTPUT = int(os.getenv("SANDBOX_MAX_OUTPUT", "20000"))
SESSION_RE = re.compile(r"^[A-Za-z0-9_-]{1,40}$")
MAX_READ = 400_000
DEPLOY_TTL = int(os.getenv("SANDBOX_DEPLOY_TTL", str(6 * 3600)))       # seconds an app keeps running (max 48 h)
MAX_DEPLOYS = int(os.getenv("SANDBOX_MAX_DEPLOYS", "3"))                # per session
MAX_WORKSPACE = int(os.getenv("SANDBOX_MAX_WORKSPACE", str(2 * 1024 ** 3)))   # bytes one session may keep (writes / uploads are refused above it)
MAX_PARALLEL = int(os.getenv("SANDBOX_MAX_PARALLEL", "4"))               # commands of ONE session at the same time
MAX_PROCS = int(os.getenv("SANDBOX_MAX_PROCS", "256"))                   # processes of one session (isolated mode)
UID_BASE = 20000
STATE = ROOT / ".state"                                                  # domains.json, mail.db, uids.json: root only, never reachable from a session
ISOLATE = os.getenv("SANDBOX_ISOLATE", "auto").strip().lower() in {"1", "true", "yes"} or (os.getenv("SANDBOX_ISOLATE", "auto").strip().lower() == "auto" and hasattr(os, "geteuid") and os.geteuid() == 0)
DEPLOYS: dict[str, dict] = {}                                           # preview token -> app


def claim_root() -> None:
    """Isolated mode (root with only CHOWN / SETUID / SETGID / KILL, no DAC_OVERRIDE): a /workspace volume of an OLDER version belongs to the old unix user
    (uid 10001), and root without DAC_OVERRIDE may not even create `.state` in it (PermissionError). CAP_CHOWN is enough to take the folder over first.
    Must run before anything touches STATE (the domain registry is read at import time)."""
    if not ISOLATE:
        return
    with contextlib.suppress(OSError):
        ROOT.mkdir(parents=True, exist_ok=True)
    for path, mode in ((ROOT, 0o711), (STATE, 0o700)):
        with contextlib.suppress(OSError):
            if path.exists():
                os.chown(path, 0, 0)
                os.chmod(path, mode)


claim_root()
HOP = {"connection", "keep-alive", "proxy-authenticate", "proxy-authorization", "te", "trailers", "transfer-encoding", "upgrade"}


class Bad(Exception):
    def __init__(self, text: str, status: int = 400):
        super().__init__(text)
        self.text, self.status = text, status


_uid_lock = threading.Lock()
_libc = None
_sem: dict[str, asyncio.Semaphore] = {}
_size_cache: dict[str, tuple[float, int]] = {}


def uid_of(session: str) -> int:
    """The unix user of a session (isolated mode): allocated once, saved in .state/uids.json."""
    with _uid_lock:
        path = STATE / "uids.json"
        try:
            data = json.loads(path.read_text("utf-8"))
        except (OSError, ValueError):
            data = {"next": UID_BASE, "map": {}}
        if session not in data["map"]:
            data["map"][session] = data["next"]
            data["next"] += 1
            tmp = path.with_suffix(".tmp")
            tmp.write_text(json.dumps(data), "utf-8")
            os.replace(tmp, path)
        return int(data["map"][session])


def workspace(session: str) -> Path:
    if not SESSION_RE.match(session or ""):
        raise Bad("bad session name (letters, digits, _ and - only)")
    path = ROOT / session
    path.mkdir(parents=True, exist_ok=True)
    if ISOLATE:
        uid = uid_of(session)
        st = path.stat()
        if st.st_uid != uid or (st.st_mode & 0o777) != 0o700:      # first time as an isolated session (or a workspace of an older version, owned by the old shared user): hand it over once
            for dirpath, dirs, files in os.walk(path):
                for name in dirs + files:
                    with contextlib.suppress(OSError):
                        os.lchown(os.path.join(dirpath, name), uid, uid)
            os.chown(path, 0, 0)                                       # root has only CAP_CHOWN (no CAP_FOWNER): take the folder, chmod it while root owns it, then give it away
            os.chmod(path, 0o700)
            os.chown(path, uid, uid)
    return path


def _fs_ids(uid: int, gid: int) -> None:
    global _libc
    if _libc is None:
        _libc = ctypes.CDLL(None, use_errno=True)
    _libc.setfsgid(gid)
    _libc.setfsuid(uid)
    if _libc.setfsuid(-1) != uid:                                       # setfsuid never fails loudly: ask again what it is now
        raise Bad("could not switch the file user (the container needs CAP_SETUID / CAP_SETGID)", 500)


@contextlib.contextmanager
def as_user(session: str):
    """Inside a worker thread: file operations run as the unix user of the session (fsuid is per thread), so a symlink trick of a session can never reach more than that session may."""
    if not ISOLATE:
        yield
        return
    uid = uid_of(session)
    _fs_ids(uid, uid)
    try:
        yield
    finally:
        _fs_ids(0, 0)


async def in_ws(session: str, fn, *args):
    """Run `fn(ws, *args)` in a thread, as the session's user."""
    ws = workspace(session)

    def job():
        with as_user(session):
            return fn(ws, *args)

    return await asyncio.to_thread(job)


def ws_size(ws: Path, session: str) -> int:
    now = time.monotonic()
    hit = _size_cache.get(session)
    if hit and now - hit[0] < 15:
        return hit[1]
    total = 0
    for dirpath, _dirs, files in os.walk(ws):
        for name in files:
            try:
                total += os.lstat(os.path.join(dirpath, name)).st_size
            except OSError:
                pass
    _size_cache[session] = (now, total)
    return total


def room_for(ws: Path, session: str, extra: int) -> None:
    if MAX_WORKSPACE and ws_size(ws, session) + extra > MAX_WORKSPACE:
        _size_cache.pop(session, None)
        raise Bad(f"the workspace is full (limit {MAX_WORKSPACE // 1024 ** 2} MB) - delete files or `.sb reset`", 507)


def inside(ws: Path, rel: str | None) -> Path:
    """A path of the workspace; anything that leaves the workspace (.., absolute, symlink) is refused."""
    rel = (rel or ".").strip().lstrip("/") or "."
    target = (ws / rel).resolve()
    if target != ws and ws not in target.parents:
        raise Bad("path leaves the workspace")
    return target


def clip(text: str) -> str:
    if len(text) <= MAX_OUTPUT:
        return text
    head = MAX_OUTPUT * 2 // 3
    return text[:head] + f"\n…[{len(text) - MAX_OUTPUT} characters cut]…\n" + text[-(MAX_OUTPUT - head):]


REGISTRY = dom.Registry(STATE / "domains.json")
MAIL = None                      # tempmail.Store, made in make_app (the state folder must exist first)


def tls_ok(request: web.Request) -> bool:
    return bool(TOKEN) and hmac.compare_digest(request.query.get("token", "").encode(), TOKEN.encode())


@web.middleware
async def guard(request: web.Request, handler):
    if request.path == "/health":
        return await handler(request)
    if request.path == "/tls/ask":                         # Caddy asks (with the token in the URL) before it orders a certificate
        return await handler(request)
    if request.path.startswith("/p/"):                    # a preview link: the secret token in the URL is the key (no Authorization header)
        return await handler(request)
    cookie = request.cookies.get("sbp")
    if cookie in DEPLOYS and "Authorization" not in request.headers:       # absolute paths (/static/app.js) of a previewed page
        return await proxy(request, cookie, request.path.lstrip("/"))
    sent = request.headers.get("Authorization", "")
    if not TOKEN or not hmac.compare_digest(sent.encode(), f"Bearer {TOKEN}".encode()):
        return web.json_response({"error": "unauthorized"}, status=401)
    try:
        return await handler(request)
    except Bad as exc:
        return web.json_response({"error": exc.text}, status=exc.status)


async def health(request: web.Request):
    return web.json_response({"ok": True, "root": str(ROOT), "isolated": ISOLATE})


def sem_of(session: str) -> asyncio.Semaphore:
    if session not in _sem:
        _sem[session] = asyncio.Semaphore(MAX_PARALLEL)
    return _sem[session]


async def run(request: web.Request):
    data = await request.json()
    session = data.get("session", "")
    ws = workspace(session)
    cmd = str(data.get("cmd") or "")
    if not cmd.strip():
        raise Bad("empty command")
    if data.get("guard"):                                  # a command written by the AI (or by an account that is not the owner): destructive / escaping / backdoor commands are refused here, not only in the client
        bad = guardrules.dangerous_command(cmd)
        if bad:
            raise Bad(f"command refused by the safety rules ({bad!r})", 403)
    cwd = inside(ws, data.get("cwd"))
    if not cwd.is_dir():
        raise Bad("cwd is not a folder")
    timeout = max(1, min(int(data.get("timeout") or 120), MAX_TIMEOUT))
    env = {"PATH": os.getenv("PATH", "/usr/local/bin:/usr/bin:/bin"), "HOME": str(ws), "LANG": "C.UTF-8", "TERM": "dumb", "PYTHONUNBUFFERED": "1",
           "DEBIAN_FRONTEND": "noninteractive", "SB_CMD": cmd}      # NOT the environment of this server: the token must never reach a command
    limits = "ulimit -f 4194304 2>/dev/null; " + (f"ulimit -u {MAX_PROCS} 2>/dev/null; umask 077; " if ISOLATE else "")
    kw = {"user": uid_of(session), "group": uid_of(session), "extra_groups": []} if ISOLATE else {}
    started = time.monotonic()
    async with sem_of(session):
        proc = await asyncio.create_subprocess_exec("bash", "-c", limits + 'eval "$SB_CMD"', cwd=str(cwd), env=env, stdin=asyncio.subprocess.DEVNULL,
                                                    stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, start_new_session=True, **kw)
        timed_out = False
        try:
            out, err = await asyncio.wait_for(proc.communicate(), timeout)
        except asyncio.TimeoutError:
            timed_out = True
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            out, err = await proc.communicate()
    return web.json_response({"code": proc.returncode, "out": clip(out.decode("utf-8", "replace")), "err": clip(err.decode("utf-8", "replace")),
                              "timed_out": timed_out, "ms": int((time.monotonic() - started) * 1000)})


async def write(request: web.Request):
    data = await request.json()
    session = data.get("session", "")
    content = data.get("content")
    if content is None:
        raise Bad("content missing")

    def job(ws: Path):
        target = inside(ws, data.get("path"))
        if target == ws or target.is_dir():
            raise Bad("path is a folder")
        room_for(ws, session, len(str(content).encode("utf-8", "replace")))
        target.parent.mkdir(parents=True, exist_ok=True)
        if data.get("append"):
            with open(target, "a", encoding="utf-8") as fh:
                fh.write(str(content))
        else:
            target.write_text(str(content), encoding="utf-8")
        return target.stat().st_size

    return web.json_response({"ok": True, "bytes": await in_ws(session, job)})


async def edit(request: web.Request):
    data = await request.json()
    session = data.get("session", "")
    old, new = str(data.get("old") or ""), str(data.get("new") or "")
    if not old:
        raise Bad("old text is empty")

    def job(ws: Path):
        target = inside(ws, data.get("path"))
        if not target.is_file():
            raise Bad("file not found", 404)
        text = target.read_text(encoding="utf-8", errors="replace")
        n = text.count(old)
        if n != 1:
            raise Bad("old text must occur exactly once (found %d times)" % n)
        target.write_text(text.replace(old, new, 1), encoding="utf-8")

    await in_ws(session, job)
    return web.json_response({"ok": True})


async def read(request: web.Request):
    session = request.query.get("session", "")

    def job(ws: Path):
        target = inside(ws, request.query.get("path"))
        if not target.is_file():
            raise Bad("file not found", 404)
        size = target.stat().st_size
        with open(target, "rb") as fh:
            raw = fh.read(MAX_READ)
        return {"text": raw.decode("utf-8", "replace"), "size": size, "cut": size > MAX_READ}

    return web.json_response(await in_ws(session, job))


async def ls(request: web.Request):
    session = request.query.get("session", "")
    since = float(request.query.get("since") or 0)

    def job(ws: Path):
        base = inside(ws, request.query.get("path"))
        if not base.exists():
            raise Bad("not found", 404)
        rows = []
        items = [base] if base.is_file() else sorted(base.rglob("*"))
        for p in items:
            if len(rows) >= 400:
                break
            try:
                st = p.lstat()
            except OSError:
                continue
            if p.name.startswith(".deploy-") or p.is_symlink() or (since and (st.st_mtime < since or p.is_dir())):
                continue
            rows.append({"path": str(p.relative_to(ws)), "dir": p.is_dir(), "size": st.st_size, "mtime": st.st_mtime})
        return rows

    return web.json_response({"items": await in_ws(session, job), "now": time.time()})


def build_zip(ws: Path, base: Path, since: float = 0.0) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(base.rglob("*") if base.is_dir() else [base]):
            if p.is_symlink() or not p.is_file():
                continue
            if since and p.stat().st_mtime < since:
                continue
            zf.write(p, p.relative_to(ws if base.is_dir() else base.parent))
    return buf.getvalue()


async def download(request: web.Request):
    """A file as it is; a folder (or the whole workspace when no path) as a zip; `since=<ts>`: only the files changed after that moment, zipped."""
    session = request.query.get("session", "")
    since = float(request.query.get("since") or 0)

    def job(ws: Path):
        target = inside(ws, request.query.get("path"))
        if not target.exists():
            raise Bad("not found", 404)
        if target.is_file() and not since:
            return "file", target.name, target.read_bytes()
        name = (target.name if target != ws else session or "workspace") + ".zip"
        return "zip", name, build_zip(ws, target, since)

    kind, name, blob = await in_ws(session, job)
    if kind == "file":
        return web.Response(body=blob, headers={"Content-Disposition": f'attachment; filename="{name}"', "Content-Type": "application/octet-stream"})
    return web.Response(body=blob, headers={"Content-Disposition": f'attachment; filename="{name}"', "Content-Type": "application/zip"})


def safe_extract(zf: zipfile.ZipFile, dest: Path) -> int:
    total = 0
    for info in zf.infolist():
        target = (dest / info.filename).resolve()
        if target != dest and dest not in target.parents:
            raise Bad("zip has a path that leaves the workspace")
        total += info.file_size
        if total > 4 * MAX_UPLOAD:
            raise Bad("zip is too big when extracted")
    zf.extractall(dest)
    return len(zf.infolist())


async def upload(request: web.Request):
    """multipart: session, dest (a folder or file name inside the workspace), extract=1 (unzip a .zip into dest), file."""
    form = {}
    blob = None
    name = "file"
    reader = await request.multipart()
    size = 0
    async for part in reader:
        if part.name == "file":
            name = part.filename or "file"
            chunks = []
            while True:
                chunk = await part.read_chunk(1 << 20)
                if not chunk:
                    break
                size += len(chunk)
                if size > MAX_UPLOAD:
                    raise Bad("file is too big", 413)
                chunks.append(chunk)
            blob = b"".join(chunks)
        else:
            form[part.name] = (await part.text())
    if blob is None:
        raise Bad("file missing")
    session = form.get("session", "")
    name = re.sub(r"[^\w.\- ]", "_", Path(name).name)[:120] or "file"

    def job(ws: Path):
        room_for(ws, session, len(blob))
        dest = inside(ws, form.get("dest"))
        if form.get("extract") == "1" and zipfile.is_zipfile(io.BytesIO(blob)):
            dest.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(io.BytesIO(blob)) as zf:
                n = safe_extract(zf, dest)
            return {"ok": True, "extracted": n, "to": str(dest.relative_to(ws))}
        if dest.is_dir() or not form.get("dest"):
            dest = dest / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(blob)
        return {"ok": True, "path": str(dest.relative_to(ws)), "bytes": len(blob)}

    return web.json_response(await in_ws(session, job))


async def web_fetch(request: web.Request):
    """{url, js: auto|true|false, max_chars}: reads a page through the gates of webread.py (see the doc of that file)."""
    if not webread.web_enabled():
        raise Bad("web reading is switched off (SANDBOX_WEB=0)", 403)
    data = await request.json()
    url = str(data.get("url") or "").strip()
    if not url:
        raise Bad("url missing")
    return web.json_response(await webread.read(url, js=data.get("js", "auto"), max_chars=int(data.get("max_chars") or 6000)))


async def reset(request: web.Request):
    data = await request.json()
    session = data.get("session", "")
    workspace(session)
    for e in [e for e in DEPLOYS.values() if e["session"] == session]:
        stop_app(e)

    def job(ws: Path):
        for child in ws.iterdir():
            child.unlink(missing_ok=True) if child.is_symlink() or not child.is_dir() else shutil.rmtree(child, ignore_errors=True)

    await in_ws(session, job)
    _size_cache.pop(session, None)
    return web.json_response({"ok": True})


# ---------------------------------------------------------------- deploy: an app of the workspace gets a preview link
def port_free(port: int) -> bool:
    import socket
    with socket.socket() as sk:
        sk.settimeout(0.2)
        return sk.connect_ex(("127.0.0.1", port)) != 0


def stop_app(entry: dict) -> None:
    try:
        os.killpg(entry["pid"], signal.SIGKILL)
    except (ProcessLookupError, PermissionError):
        pass
    DEPLOYS.pop(entry["token"], None)


def tail_of(path: Path, chars: int = 1500) -> str:
    try:
        return path.read_text(errors="replace")[-chars:]
    except OSError:
        return ""


def public_url(token: str) -> str:
    """The https link of a preview on one of the verified domains with SSL ('' when there is none: the bot then uses SANDBOX_PUBLIC_URL / SANDBOX_URL)."""
    base = REGISTRY.public_base()
    return f"{base}/p/{token}/" if base else ""


async def deploy(request: web.Request):
    """{session, cmd, name?, ttl?, wait?}: starts `cmd` in the background (it must listen on $PORT) and returns the preview path /p/<token>/."""
    data = await request.json()
    session = data.get("session", "")
    ws = workspace(session)
    cmd = str(data.get("cmd") or "").strip()
    name = re.sub(r"[^A-Za-z0-9_-]", "", str(data.get("name") or "app"))[:30] or "app"
    if not cmd:
        raise Bad("empty command")
    if data.get("guard"):
        bad = guardrules.dangerous_command(cmd)
        if bad:
            raise Bad(f"command refused by the safety rules ({bad!r})", 403)
    for old in [e for e in DEPLOYS.values() if e["session"] == session and e["name"] == name]:
        stop_app(old)
    if sum(1 for e in DEPLOYS.values() if e["session"] == session) >= MAX_DEPLOYS:
        raise Bad(f"at most {MAX_DEPLOYS} running apps per session (stop one first)", 409)
    port = next((p for p in random.sample(range(9000, 10000), 60) if port_free(p)), None)
    if port is None:
        raise Bad("no free port", 503)
    log_path = ws / f".deploy-{name}.log"

    def open_log(_ws: Path):
        if log_path.is_symlink():
            log_path.unlink()
        return open(log_path, "wb")                         # opened AS the session's user: a symlink there can not reach a file of another user

    logf = await in_ws(session, open_log)
    env = {"PATH": os.getenv("PATH", "/usr/local/bin:/usr/bin:/bin"), "HOME": str(ws), "LANG": "C.UTF-8", "PORT": str(port), "HOST": "127.0.0.1", "PYTHONUNBUFFERED": "1", "SB_CMD": cmd}
    kw = {"user": uid_of(session), "group": uid_of(session), "extra_groups": []} if ISOLATE else {}
    limits = "ulimit -f 4194304 2>/dev/null; " + (f"ulimit -u {MAX_PROCS} 2>/dev/null; umask 077; " if ISOLATE else "")
    with logf:
        proc = await asyncio.create_subprocess_exec("bash", "-c", limits + 'eval "$SB_CMD"', cwd=str(ws), env=env, stdin=asyncio.subprocess.DEVNULL, stdout=logf, stderr=logf,
                                                    start_new_session=True, **kw)
    token = secrets.token_urlsafe(18)
    ttl = max(60, min(int(data.get("ttl") or DEPLOY_TTL), 48 * 3600))
    entry = {"token": token, "session": session, "name": name, "port": port, "pid": proc.pid, "cmd": cmd, "started": time.time(), "until": time.time() + ttl, "log": str(log_path)}
    DEPLOYS[token] = entry

    async def reaper():
        await asyncio.sleep(ttl)
        if DEPLOYS.get(token) is entry:
            stop_app(entry)

    asyncio.get_running_loop().create_task(reaper())
    ready = False
    for _ in range(max(1, min(int(data.get("wait") or 20), 60)) * 5):
        if proc.returncode is not None:
            break
        if not port_free(port):
            ready = True
            break
        await asyncio.sleep(0.2)
    if proc.returncode is not None and not ready:
        DEPLOYS.pop(token, None)
    log = await in_ws(session, lambda _ws: tail_of(log_path))
    return web.json_response({"ok": ready, "token": token, "name": name, "port": port, "path": f"/p/{token}/", "public": public_url(token) if ready else "", "ready": ready,
                              "exited": proc.returncode, "log": log, "expires_in": ttl})


async def deploys(request: web.Request):
    session = request.query.get("session", "")
    workspace(session)
    return web.json_response({"apps": [{"name": e["name"], "port": e["port"], "path": f"/p/{e['token']}/", "public": public_url(e["token"]), "cmd": e["cmd"][:120],
                                        "expires_in": int(e["until"] - time.time())} for e in DEPLOYS.values() if e["session"] == session]})


async def deploy_stop(request: web.Request):
    data = await request.json()
    n = 0
    for e in [e for e in DEPLOYS.values() if e["session"] == data.get("session") and (data.get("name") in (None, "", "all") or e["name"] == data.get("name"))]:
        stop_app(e)
        n += 1
    return web.json_response({"ok": True, "stopped": n})


async def deploy_logs(request: web.Request):
    session = request.query.get("session", "")
    name = re.sub(r"[^A-Za-z0-9_-]", "", request.query.get("name", "app")) or "app"
    return web.json_response({"log": await in_ws(session, lambda ws: tail_of(ws / f".deploy-{name}.log", 6000))})


async def proxy(request: web.Request, token: str, tail: str):
    entry = DEPLOYS.get(token)
    if entry is None:
        raise web.HTTPNotFound(text="this preview link is not running (expired or stopped)")
    body = await request.read()
    headers = {k: v for k, v in request.headers.items() if k.lower() not in HOP | {"host", "cookie", "authorization", "accept-encoding", "content-length"}}
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=60), auto_decompress=True) as s:
            async with s.request(request.method, f"http://127.0.0.1:{entry['port']}/{tail}", params=request.query, data=body or None, headers=headers, allow_redirects=False) as r:
                data = await r.read()
                out = {k: v for k, v in r.headers.items() if k.lower() not in HOP | {"content-length", "content-encoding", "set-cookie"}}
                resp = web.Response(body=data, status=r.status, headers=out)
    except (aiohttp.ClientError, asyncio.TimeoutError):
        text = await in_ws(entry["session"], lambda _ws: tail_of(Path(entry["log"])))
        return web.Response(status=502, text="the app does not answer yet / any more.\n\n" + text, content_type="text/plain")
    resp.set_cookie("sbp", token, path="/", httponly=True, samesite="Lax", max_age=3600)
    return resp


async def preview(request: web.Request):
    return await proxy(request, request.match_info["token"], request.match_info.get("tail", ""))


# ---------------------------------------------------------------- verified domains + SSL
async def tls_ask(request: web.Request):
    """Caddy (on-demand TLS) asks before it orders a certificate: 200 only for a registered domain or a sub-domain of one."""
    if not tls_ok(request):
        return web.Response(status=401, text="unauthorized")
    return web.Response(status=200 if REGISTRY.allowed(request.query.get("domain", "")) else 403, text="")


def domain_rows() -> list[dict]:
    out = []
    for name, r in sorted(REGISTRY.all().items()):
        out.append({"name": name, "ssl": bool(r.get("ssl")), "ssl_error": r.get("ssl_error", ""), "mail": bool(r.get("mail")), "wild_mx": bool(r.get("wild_mx")),
                    "a_ok": r.get("a_ok"), "covered_by": r.get("covered_by"), "added": r.get("added"), "checked": r.get("checked")})
    return out


async def domains_list(request: web.Request):
    return web.json_response({"domains": domain_rows(), "ip": await dom.server_ip(), "tls": bool(os.getenv("SANDBOX_TLS_HOST", "").strip())})


async def domains_add(request: web.Request):
    """{domain, ip?}: register + DNS check + certificate NOW (also the re-check of an existing one); `ip` = the server's IP when the automatic detection is wrong."""
    data = await request.json()
    return web.json_response(await dom.add_or_check(REGISTRY, str(data.get("domain") or ""), ip=str(data.get("ip") or "")))


async def domains_diag(request: web.Request):
    data = await request.json()
    return web.json_response({"ok": True, "text": await dom.diagnose(str(data.get("domain") or ""))})


async def domains_remove(request: web.Request):
    data = await request.json()
    name = dom.normalize(str(data.get("domain") or ""))
    return web.json_response({"ok": REGISTRY.remove(name), "domain": name})


async def domains_mail(request: web.Request):
    """{domain, on}: force the mail flag (the MX check cannot see a forwarder)."""
    data = await request.json()
    name = dom.normalize(str(data.get("domain") or ""))
    if REGISTRY.get(name) is None:
        raise Bad("domain is not registered", 404)
    on = bool(data.get("on"))
    REGISTRY.put(name, mail=on, mail_forced=on)
    return web.json_response({"ok": True, "domain": name, "mail": on})


# ---------------------------------------------------------------- temporary mail (.mail)
def need_mail() -> tempmail.Store:
    if MAIL is None:
        raise Bad("mail is not available", 503)
    return MAIL


async def mail_new(request: web.Request):
    data = await request.json()
    session = data.get("session", "")
    workspace(session)
    domains = REGISTRY.mail_domains()
    if not domains:
        raise Bad("no domain that can receive mail yet (the owner adds one with `.sb domain add`, its MX must point to this server)", 409)
    a = await asyncio.to_thread(need_mail().new_address, session, domains)
    return web.json_response({"ok": True, **a, "smtp": bool(os.getenv("SANDBOX_SMTP_PORT", "2525") not in ("", "0"))})


async def mail_list(request: web.Request):
    session = request.query.get("session", "")
    workspace(session)
    return web.json_response({"items": await asyncio.to_thread(need_mail().list_addresses, session), "domains": len(REGISTRY.mail_domains())})


async def mail_inbox(request: web.Request):
    session = request.query.get("session", "")
    workspace(session)
    res = await asyncio.to_thread(need_mail().messages, session, int(request.query.get("aid") or 0), int(request.query.get("limit") or 6), int(request.query.get("offset") or 0))
    if not res.get("ok"):
        raise Bad(res.get("error", "not found"), 404)
    return web.json_response(res)


async def mail_message(request: web.Request):
    session = request.query.get("session", "")
    workspace(session)
    m = await asyncio.to_thread(need_mail().message, session, int(request.query.get("aid") or 0), int(request.query.get("mid") or 0))
    if m is None:
        raise Bad("no such mail", 404)
    return web.json_response(m)


async def mail_delete(request: web.Request):
    data = await request.json()
    session = data.get("session", "")
    workspace(session)
    return web.json_response({"ok": await asyncio.to_thread(need_mail().delete_address, session, int(data.get("aid") or 0))})


def make_app() -> web.Application:
    global MAIL
    if ISOLATE:
        ROOT.mkdir(parents=True, exist_ok=True)
        os.chmod(ROOT, 0o711)                              # sessions may enter their own folder but never list the others
    STATE.mkdir(parents=True, exist_ok=True)
    if ISOLATE:
        os.chmod(STATE, 0o700)
    MAIL = tempmail.Store(STATE / "mail.db")
    app = web.Application(middlewares=[guard], client_max_size=MAX_UPLOAD + (1 << 20))
    app.add_routes([web.get("/health", health), web.post("/exec", run), web.post("/write", write), web.post("/edit", edit), web.get("/read", read),
                    web.get("/ls", ls), web.get("/download", download), web.post("/upload", upload), web.post("/reset", reset), web.post("/web/fetch", web_fetch), web.post("/deploy", deploy), web.get("/deploys", deploys), web.post("/deploy/stop", deploy_stop),
                    web.get("/deploy/logs", deploy_logs), web.route("*", "/p/{token}/{tail:.*}", preview), web.route("*", "/p/{token}", preview),
                    web.get("/tls/ask", tls_ask), web.get("/domains", domains_list), web.post("/domains/add", domains_add), web.post("/domains/remove", domains_remove), web.post("/domains/diag", domains_diag),
                    web.post("/domains/mail", domains_mail), web.post("/mail/new", mail_new), web.get("/mail/list", mail_list), web.get("/mail/inbox", mail_inbox),
                    web.get("/mail/message", mail_message), web.post("/mail/delete", mail_delete)])

    async def background(app_: web.Application):
        smtp = tempmail.start_smtp(MAIL)

        async def sweeper():
            while True:
                await asyncio.sleep(600)
                try:
                    await asyncio.to_thread(MAIL.purge)
                except Exception:  # noqa: BLE001
                    pass

        task = asyncio.get_running_loop().create_task(sweeper())
        yield
        task.cancel()
        if smtp is not None:
            smtp.stop()

    app.cleanup_ctx.append(background)
    return app


if __name__ == "__main__":
    if len(TOKEN) < 16:
        raise SystemExit("SANDBOX_TOKEN is missing or too short (use at least 16 random characters, e.g. `openssl rand -hex 24`)")
    ROOT.mkdir(parents=True, exist_ok=True)
    web.run_app(make_app(), host=os.getenv("SANDBOX_HOST", "0.0.0.0"), port=int(os.getenv("SANDBOX_PORT", "8765")), print=None)
