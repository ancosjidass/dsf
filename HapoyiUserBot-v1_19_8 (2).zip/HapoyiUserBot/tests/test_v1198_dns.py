"""1.19.8: the domain check no longer calls correct DNS records «wrong» (authoritative lookup, unknown != wrong, several server IPs, IP override, Cloudflare hint)."""
from __future__ import annotations

import asyncio

from sandbox_server import domains as D


class Rec:
    def __init__(self, **kw):
        self.__dict__.update(kw)


def A(ip):
    return [Rec(address=ip)]


def MX(pref, host):
    return [Rec(preference=pref, exchange=host + ".")]


def fake_dns(monkeypatch, zone, fail=False):
    zone = {("ns1.example.com", "A"): A("9.9.9.9"), **zone}

    async def ask(name, rdtype, nameservers=None, lifetime=4.0):
        if fail:
            return [], "error"
        if rdtype == "NS":
            return ([Rec(target="ns1.example.com.")], "ok") if name == "example.com" else ([], "none")
        recs = zone.get((name, rdtype))
        if recs is None and "." in name:
            recs = zone.get(("*." + name.split(".", 1)[1], rdtype))
        return (recs, "ok") if recs else ([], "none")

    monkeypatch.setattr(D, "_ask", ask)


GOOD = {("example.com", "A"): A("1.2.3.4"), ("*.example.com", "A"): A("1.2.3.4"), ("example.com", "MX"): MX(10, "example.com"), ("*.example.com", "MX"): MX(10, "example.com")}


def test_correct_records_are_green(monkeypatch):
    fake_dns(monkeypatch, GOOD)
    r = asyncio.run(D.dns_report("example.com", "1.2.3.4"))
    assert r["a_ok"] is True and r["mx_ok"] is True and r["wild_mx"] is True and not r["lookup_failed"]


def test_mx_on_another_host_of_the_domain(monkeypatch):
    fake_dns(monkeypatch, {("example.com", "A"): A("1.2.3.4"), ("mail.example.com", "A"): A("1.2.3.4"), ("example.com", "MX"): MX(10, "mail.example.com")})
    r = asyncio.run(D.dns_report("example.com", "1.2.3.4"))
    assert r["mx_ok"] is True and r["wild_mx"] is False


def test_a_failed_lookup_is_unknown_not_wrong(monkeypatch):
    fake_dns(monkeypatch, {}, fail=True)

    async def no_system(*a, **k):
        raise OSError

    monkeypatch.setattr(D.socket, "getaddrinfo", lambda *a, **k: (_ for _ in ()).throw(OSError()))
    r = asyncio.run(D.dns_report("example.com", "1.2.3.4"))
    assert r["a_ok"] is None and r["mx_ok"] is None and r["lookup_failed"] is True


def test_missing_records_are_wrong_and_explained(monkeypatch):
    fake_dns(monkeypatch, {})
    r = asyncio.run(D.dns_report("example.com", "1.2.3.4"))
    assert r["a_ok"] is False and r["mx_ok"] is False
    assert len(D.dns_problems("example.com", r)) == 2


def test_cloudflare_proxy_is_recognised(monkeypatch):
    fake_dns(monkeypatch, {("example.com", "A"): A("104.21.5.5"), ("example.com", "MX"): MX(10, "example.com")})
    r = asyncio.run(D.dns_report("example.com", "1.2.3.4"))
    assert r["a_ok"] is False and r["cloudflare"] is True and "Cloudflare" in D.dns_problems("example.com", r)[0]


def test_several_server_ips_and_unknown_own_ip(monkeypatch):
    fake_dns(monkeypatch, {("example.com", "A"): A("5.6.7.8"), ("example.com", "MX"): MX(10, "example.com")})
    r = asyncio.run(D.dns_report("example.com", "1.2.3.4, 5.6.7.8"))
    assert r["a_ok"] is True and r["mx_ok"] is True
    r = asyncio.run(D.dns_report("example.com", ""))
    assert r["a_ok"] is None and r["mx_ok"] is True            # our own IP is unknown: «we do not know», never «wrong»


def test_ip_override_fixes_a_wrong_detection(tmp_path, monkeypatch):
    fake_dns(monkeypatch, GOOD)

    async def detected():
        return "8.8.4.4"                                      # wrong (VPN / WARP / NAT)

    async def warm(name, timeout=75.0):
        return True, ""

    monkeypatch.setattr(D, "server_ip", detected)
    monkeypatch.setattr(D, "warm_tls", warm)
    reg = D.Registry(tmp_path / "d.json")
    r = asyncio.run(D.add_or_check(reg, "example.com"))
    assert r["status"] == "pending" and not r["mail"] and any("1.2.3.4" in p for p in r["problems"])
    r = asyncio.run(D.add_or_check(reg, "example.com", ip="1.2.3.4"))
    assert r["status"] == "ready" and r["mail"] and not r["problems"] and reg.mail_domains()[0]["name"] == "example.com"
    assert asyncio.run(D.add_or_check(reg, "example.com", ip="999.1.1.1"))["ok"] is False


def test_ip_helpers():
    assert D.ip_set("1.2.3.4, 5.6.7.8;nonsense 300.1.1.1") == {"1.2.3.4", "5.6.7.8"}
    assert D.behind_cloudflare(["104.16.1.1"]) and not D.behind_cloudflare(["1.2.3.4"])
